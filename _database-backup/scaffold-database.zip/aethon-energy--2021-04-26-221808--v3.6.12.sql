-- MariaDB dump 10.19  Distrib 10.5.9-MariaDB, for Linux (x86_64)
--
-- Host: mysql-5.7-3306.database.nitro    Database: aethon
-- ------------------------------------------------------
-- Server version	5.7.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `volumeId` int(11) NOT NULL,
  `uri` text COLLATE utf8_unicode_ci,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bekjxdiybzdbnahwerviamdnpjazgbdtzyfc` (`sessionId`,`volumeId`),
  KEY `idx_ehrnbgpxjnoiwupurjbfucdnboxuyjsnjnzm` (`volumeId`),
  CONSTRAINT `fk_nmorvjitamyklvulqpuavhzrmmdurwptpwfd` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kind` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dwhvvukjzoiexdfhuvsribnuaimqiorooept` (`filename`,`folderId`),
  KEY `idx_fydkrslheysadwdzrhshjpossssnbvjjrfbx` (`folderId`),
  KEY `idx_lrsjmsndxqrfjvgjglimawlbnekhlsbdrqcy` (`volumeId`),
  KEY `fk_qghvccvqfgrpqsgmrvwjkecprbmjulwaayey` (`uploaderId`),
  CONSTRAINT `fk_qghvccvqfgrpqsgmrvwjkecprbmjulwaayey` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_qzdhrouwfgbeiyckzcgfhmxjvpkcszwxfnqk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wgddxfucxbelgdxqemjpfrpkfzqutytjntgz` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yvxjxurcpmohqlyxlovgadkaxrafeiqhixxc` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assettransformindex`
--

DROP TABLE IF EXISTS `assettransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_giljvuzwwerapxiddlpldckdxtwuuaxlphvo` (`volumeId`,`assetId`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assettransforms`
--

DROP TABLE IF EXISTS `assettransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mode` enum('stretch','fit','crop') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'none',
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_klfaennfslgdoihsupdyiypjrvhtbarayzdw` (`name`),
  KEY `idx_tpaneveppuawlrjpdwkmrhacxeosabodlfoe` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_truxzcfjqawrimegxznvtjnqouxmfdhvgkim` (`groupId`),
  KEY `fk_fmdypstrwomkvzbqybntwqatewukacszlwgz` (`parentId`),
  CONSTRAINT `fk_fmdypstrwomkvzbqybntwqatewukacszlwgz` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_razskzzcjfjtjvcslauvwhzvfdsyiixseoya` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_seuuppawwslwxyglqginmiiluxpatmfzocxc` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yjrvefbpeujbdrmanyqezenoyahgoknjzulh` (`name`),
  KEY `idx_errjvqdtszxjiuqgofehnvonvmpihcgbppjo` (`handle`),
  KEY `idx_ampququtnywzjkukkzmxtepphcqeoippnwgu` (`structureId`),
  KEY `idx_aeyzmqgztyudfdkhseywijxcclwodlunsvyy` (`fieldLayoutId`),
  KEY `idx_gohmdxzwhvraumshnsleqshfxvxdvfymwwup` (`dateDeleted`),
  CONSTRAINT `fk_nikkjgrghuhuautsiwpjgsqdtyjdxdmlmgke` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_qybromojeuhlprstmqoeavhdkcrbdsnlszlc` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text COLLATE utf8_unicode_ci,
  `template` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nrosmfzwdvhfpintbqmnudoublvpqiddpcsz` (`groupId`,`siteId`),
  KEY `idx_blugjzllrndcuzngijpgpbwqkpnkazobhuao` (`siteId`),
  CONSTRAINT `fk_dzfctlczueuriyunsdfwpjailkxiomtxcriy` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kefqcnkyrbdjzvtmwjpmnovnnzsmgtrmypem` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedattributes` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `attribute` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_dooxhrfjezzomklgcpiwbqsvubfedunvlsvt` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_ygeaxbtzgwespgbozicdgklxocgarfxcdaqg` (`siteId`),
  KEY `fk_jlcsqlmyghvxvibjrmkuvnhtdvrechbixhuf` (`userId`),
  CONSTRAINT `fk_jlcsqlmyghvxvibjrmkuvnhtdvrechbixhuf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_ncezsgvtmdohazgurqglosaknddilfgjxrtd` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ygeaxbtzgwespgbozicdgklxocgarfxcdaqg` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedfields` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_epgdnetlhzvdraacutliftngezwierkvrwlk` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_noovbkcfmglnfxgoxlmddzgmijvwgquguuas` (`siteId`),
  KEY `fk_olcisucmqajydqnrzgsajpraqjiqvxnxfugh` (`fieldId`),
  KEY `fk_satydnmtznolctpubymhkthqjabszdmpvlvu` (`userId`),
  CONSTRAINT `fk_dkyduxronnckeiewipfjrpntcsvotjjfhvcv` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_noovbkcfmglnfxgoxlmddzgmijvwgquguuas` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_olcisucmqajydqnrzgsajpraqjiqvxnxfugh` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_satydnmtznolctpubymhkthqjabszdmpvlvu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contactform_submissions`
--

DROP TABLE IF EXISTS `contactform_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contactform_submissions` (
  `id` int(11) NOT NULL,
  `form` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fromName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fromEmail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_ppprssocvuxuzdzahkgmaomfogmxpalrcozx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mwnnzcfoskhxgofsclgofntinhwvqnsazpso` (`elementId`,`siteId`),
  KEY `idx_soavuvhvradhtxdirozbywuiafptekkqdizo` (`siteId`),
  KEY `idx_ejseftfawfglmjrjbtznyzmduryoethrjleu` (`title`),
  CONSTRAINT `fk_eiaoqfsdbpuwumjlbnxfxjcywyvnuickrmbh` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_najoseavxinyyoqzsmhagbmegdtaqoecxglw` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text COLLATE utf8_unicode_ci NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_bpnpdafkwnxjkohavelkppmxdntokybchlop` (`userId`),
  CONSTRAINT `fk_bpnpdafkwnxjkohavelkppmxdntokybchlop` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fingerprint` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `traces` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_twncmmxsddzetxomriozfvragfvxbtewvcri` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sourceId` int(11) DEFAULT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_upyownsjfygohllwzrxshqkvtzdbrwbfwluq` (`saved`),
  KEY `fk_whqxnvxqlxiuflqluxmstfrmyckfvyirtpgl` (`creatorId`),
  KEY `fk_nylzgzaiulkqldnqvdtmwynqzaqmzmexnwvj` (`sourceId`),
  CONSTRAINT `fk_nylzgzaiulkqldnqvdtmwynqzaqmzmexnwvj` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_whqxnvxqlxiuflqluxmstfrmyckfvyirtpgl` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementindexsettings`
--

DROP TABLE IF EXISTS `elementindexsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_goslprvbtdlcgjcycfagvxihnwhnjeucldnh` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_iabslaywxezvrwryiifbolqsklkqdoubtzhs` (`dateDeleted`),
  KEY `idx_ldwuchvhhuvijblbefmvliijwfctrmotsoih` (`fieldLayoutId`),
  KEY `idx_rpxchkdieoddnutssjroicylgjzlzddpyydu` (`type`),
  KEY `idx_spsvxxiksoozznmgignvtpvfwbxngszdbgqg` (`enabled`),
  KEY `idx_anillztlztlzaswjwnbtpzrmrokiffcqttum` (`archived`,`dateCreated`),
  KEY `idx_tacqlrlyhuocyenxxkylmpsfqgxtffvlsnrz` (`archived`,`dateDeleted`,`draftId`,`revisionId`),
  KEY `fk_ajfpaotkbgnewyjhzeszhebwetrosxruqbmt` (`draftId`),
  KEY `fk_efassrcgnmbianfiomxnufayngxkbguaiggm` (`revisionId`),
  CONSTRAINT `fk_ajfpaotkbgnewyjhzeszhebwetrosxruqbmt` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_efassrcgnmbianfiomxnufayngxkbguaiggm` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qnzbzuvjahbmevjxvjbwbdncksxeavohnllj` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pcfbzmuliluraflvxromhxegrfwtmdajvyep` (`elementId`,`siteId`),
  KEY `idx_lgmiumhbjrbzoeersyzkgdyfijuejbutopuw` (`siteId`),
  KEY `idx_vocuugrvunqmscjsohjnsdlmfuhywodmroce` (`slug`,`siteId`),
  KEY `idx_pkuqmwzzownkmkjsjuuwhkreercgkiupnxbd` (`enabled`),
  KEY `idx_quryzkjomobuorsaziqayarxsisncpshcuwj` (`uri`,`siteId`),
  CONSTRAINT `fk_tjgpfpjgftdrkrsiwsraitgsqbxyxiqkdngr` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xiyytaiacvnjifnwbyisdqfmwhhosglixdzp` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cofhuqpqtwrirprjcjecdqvlpqfggzsmrusa` (`postDate`),
  KEY `idx_wjknyersywrqxxbqzlhdcdundxrntuzdysfl` (`expiryDate`),
  KEY `idx_bcuxvlmvvlswwxtsizldnqqithyikiofqoqt` (`authorId`),
  KEY `idx_mwzaqjegvbcwvovirgsspgbqaniqkghmdzou` (`sectionId`),
  KEY `idx_gzdvecepdertvjdsihlmedhewzprxxwmslmg` (`typeId`),
  KEY `fk_ybduknofbbcnffrvjlwbybziltaharmcmcrf` (`parentId`),
  CONSTRAINT `fk_daphfxxwrdxwretklobmfwswanvcabrcxbld` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ekvgkfotmeufcovrcfgpmnmqfgrvvmegetrz` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_enqzbkggbhptpltbyhrzltjtatcvygjcmpzn` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ldezqoyqecxcxrgfzoutxwryqfoazzntomyz` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ybduknofbbcnffrvjlwbybziltaharmcmcrf` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text COLLATE utf8_unicode_ci,
  `titleFormat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qrwvvsxcldsgvunrzjfgraoellpjjwdbctmy` (`name`,`sectionId`),
  KEY `idx_ydmeahiagckqcfypdxrywcvzvhqrmdfrtahn` (`handle`,`sectionId`),
  KEY `idx_asryfccvydalpjiquyshnzbnpnhrzbecfgzt` (`sectionId`),
  KEY `idx_askkkdsmaxauyhmcxfzlviztuvucqurhchol` (`fieldLayoutId`),
  KEY `idx_odlgkrwqifckryzrahragqqawoonusdmwqtv` (`dateDeleted`),
  CONSTRAINT `fk_qlqeqfsmompeesrsyrfojpzhqrbctxiznsxu` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ylbeagjwbmiwyisfmzjildckraoelyvajdxz` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wgrmbhhlpqcfwzwtfoufldwpapdluoyoaskg` (`name`),
  KEY `idx_xayfpyahwxukjrcmljciljmtrwuquxtmacwz` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_blxtesanyiwuusgolmlotlkrwcntiouxaoft` (`layoutId`,`fieldId`),
  KEY `idx_glkavquctjkjcscrakitxumpunlheiginudc` (`sortOrder`),
  KEY `idx_jukjepnhwarwaqixulfzywvrzisbngoliizf` (`tabId`),
  KEY `idx_pakmnsccecjoxwaukwzierwlzgsoeotjdayq` (`fieldId`),
  CONSTRAINT `fk_nlmxkdyzsqijljljswcdjwyonqiggtpxtjfq` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ofxfkhymnitsriietsgbbpoulrpcwucezdvc` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yqpeddxuxpqsthouzzcsqbvwcrnkhusieycv` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_umgtggqmflnteluncfhmjtxaarlgegtygole` (`dateDeleted`),
  KEY `idx_uskyacxnrxcvytuejvckzxstyzzhidffodaz` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `elements` text COLLATE utf8_unicode_ci,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yxctcsevekbautqkfznjmxgluzqqvjdwolig` (`sortOrder`),
  KEY `idx_ogrtvfohtutbwvnmhzhnppuasgmvamwrdurg` (`layoutId`),
  CONSTRAINT `fk_soxspahukxsomsvwboadtvctgianltczhndl` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `context` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'global',
  `instructions` text COLLATE utf8_unicode_ci,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'none',
  `translationKeyFormat` text COLLATE utf8_unicode_ci,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ymmdcqcogiafnnswvmrffdpsrvhrusrsaxao` (`handle`,`context`),
  KEY `idx_fkovdnkqwkshmhvjzomfbjdatxjlcybfbjdv` (`groupId`),
  KEY `idx_skgkxzqxmtxznuxwvzawmumnosbhxngxfdcy` (`context`),
  CONSTRAINT `fk_lixhjcxgldpchzhkxzxydchqjwbhscezxojr` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ahrwxxmmxjixiigsqjjdkylnhghtghsnghhe` (`name`),
  KEY `idx_svmnvlsqcyqwbwgjwpgnmdjubavewpderfhg` (`handle`),
  KEY `idx_gzazutplhotafibmlgjtedyuxgchoocutxjr` (`fieldLayoutId`),
  CONSTRAINT `fk_cfrfvcihanuuzkndjjlsubykfzxuzjigzsjp` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_oevegzstvwkbmgzwepxdatzglueyxxzdmbid` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqlschemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `scope` text COLLATE utf8_unicode_ci,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqltokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `accessToken` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jxrdlyefqklkgyuvwepnlxsnznprjjuguagm` (`accessToken`),
  UNIQUE KEY `idx_ixorqgbnspxilorqffmjdzjqpazuxzvaixhc` (`name`),
  KEY `fk_eyczxtzjyyqsybppxvxmppihwzcmbojgfcpq` (`schemaId`),
  CONSTRAINT `fk_eyczxtzjyyqsybppxvxmppihwzcmbojgfcpq` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `schemaVersion` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pppzlxphchfsukcybalospjfuukpvjejqfcr` (`ownerId`),
  KEY `idx_izftsxdcgkwferxbvydhcyjisgzaqtwvweta` (`fieldId`),
  KEY `idx_dglxbqzwoggoezxjcbbvuekjdbgiyrkjexqy` (`typeId`),
  KEY `idx_nqqderajuewmjqajxcyieamlilgaduvcltan` (`sortOrder`),
  CONSTRAINT `fk_aizanhuztmszytbppsaexxssixlepfwoclak` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_czxjdoktsbjjnjfujegnagvocvdedrdzsnhx` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ikhhxawkufuuartnmwxcokxbczzyhxbqsart` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zgplafgpjjzlqqfvhmzuduhobmbfbqmpytzk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bqxqiyveakxjjotfnnwxfiyergbcbymtrrko` (`name`,`fieldId`),
  KEY `idx_gdosclebcfzategvwlkaogpcculcjhlunwot` (`handle`,`fieldId`),
  KEY `idx_gzohtdlkerevaagbpemcmqpdvcqmzmjsftpj` (`fieldId`),
  KEY `idx_jkavkzpesgshpthnedwugxvhacixwtskvsij` (`fieldLayoutId`),
  CONSTRAINT `fk_gvxqcmwzomjbyjazhvwcklglkdvfpftqxkjm` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zvphdpvkbwqzhvtthhxolrvdloummsogyzhu` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `track` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nkorrmauzgrrfshvwdiptvwquzagknfcizln` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=229 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `navigation_navs`
--

DROP TABLE IF EXISTS `navigation_navs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `navigation_navs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `instructions` text COLLATE utf8_unicode_ci,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `propagateNodes` tinyint(1) DEFAULT '0',
  `maxNodes` int(11) DEFAULT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `siteSettings` text COLLATE utf8_unicode_ci,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rkeojrpskxhhirzeazuapgirxxavxngdyeum` (`handle`),
  KEY `idx_biqhhscbywwqghwdrufdurkjzvmhoylyvtnv` (`structureId`),
  KEY `idx_fxbcitbgpuwmcyninxlsoxcvbnugqajqscuh` (`fieldLayoutId`),
  KEY `idx_xrucvcleczsnfdbkfbsehiqkjtptubpauxgi` (`dateDeleted`),
  CONSTRAINT `fk_jzcohucylfvbvdcpburouwhsgdzgujaqkvqg` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xqnoimgjelodblezvwkdoquklfrwtgaacuaz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `navigation_nodes`
--

DROP TABLE IF EXISTS `navigation_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `navigation_nodes` (
  `id` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `navId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `classes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `urlSuffix` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customAttributes` text COLLATE utf8_unicode_ci,
  `data` text COLLATE utf8_unicode_ci,
  `newWindow` tinyint(1) DEFAULT '0',
  `deletedWithNav` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qpusjpxidlwutkapgluujfapzaunaxbcfwmo` (`navId`),
  KEY `fk_hkpzvxbjuiwsicncnysnzagtsndkaukljgeo` (`elementId`),
  CONSTRAINT `fk_cwwuirpowthdzxhyotfdfhkgvcqzlqttiwkg` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hkpzvxbjuiwsicncnysnzagtsndkaukljgeo` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_kmselnbyupdgyupikkbegbrfxynmcydoxywb` FOREIGN KEY (`navId`) REFERENCES `navigation_navs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `neoblocks`
--

DROP TABLE IF EXISTS `neoblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `neoblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uswdwlmssseglewgdsmwwtinvnmlllhzyziv` (`ownerId`),
  KEY `idx_hjbzhkptgbcloulcjdaqaxrjaixxbwftkmsn` (`ownerSiteId`),
  KEY `idx_wodpkocphcbzgtgtgnisitbedlsddqtlmqvf` (`fieldId`),
  KEY `idx_iiqgievqboqvoecplqcewobrjacortakdhkm` (`typeId`),
  CONSTRAINT `fk_eettlfkbqxxyrzcpvnqubtrbqglucyqyhble` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ixrnxxdwveidyikxgmnojwmohprphgidguch` FOREIGN KEY (`typeId`) REFERENCES `neoblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tnywgegcjswgldurhanepupuahtwnaantggw` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vfiojbpmjrslizcegwjltvpeghtoqvcchbnj` FOREIGN KEY (`ownerSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xspoeebmmocpltbflkjcxdsafvbitrjggqcf` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `neoblockstructures`
--

DROP TABLE IF EXISTS `neoblockstructures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `neoblockstructures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ylghevebexqyvrgjjiguaionqyqovmsgsfuu` (`structureId`),
  KEY `idx_igzcyvvlpeqxgyxvxqouavgdnecrcnvxllcc` (`ownerId`),
  KEY `idx_qhkckyfmfixbhkmqdtubkwnkytjibddaixtj` (`ownerSiteId`),
  KEY `idx_qvhtmztxtskacjsdcuhfxrkkrxhmqsbwywvh` (`fieldId`),
  CONSTRAINT `fk_egimyfvhzfqdnlqzgimqhefctleiemlgezcw` FOREIGN KEY (`ownerSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jvpbapbtbxttjmwmbqwqdsizddgfaiyllzld` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mhvurmilpleyrupgsbudvjzpkglbhtmjbych` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vqtwlkgvctmesxjfdkmvbtvywdfulpputyxt` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `neoblocktypegroups`
--

DROP TABLE IF EXISTS `neoblocktypegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `neoblocktypegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vcwghplwnneljhjajwbozqwuypgtumklppuo` (`name`,`fieldId`),
  KEY `idx_kvlrbjokacfgquxyteeqzflhnkvutfvbmsbt` (`fieldId`),
  CONSTRAINT `fk_srsaylteelcstcnsztljqzmhtjxfffjmrjvp` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `neoblocktypes`
--

DROP TABLE IF EXISTS `neoblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `neoblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `maxBlocks` smallint(6) unsigned DEFAULT NULL,
  `maxSiblingBlocks` smallint(6) unsigned DEFAULT '0',
  `maxChildBlocks` smallint(6) unsigned DEFAULT NULL,
  `childBlocks` text COLLATE utf8_unicode_ci,
  `topLevel` tinyint(1) NOT NULL DEFAULT '1',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dhrznfbtwkglpmqmepyqfckdhyjwcthsipvd` (`handle`,`fieldId`),
  KEY `idx_nvlhhchtubburzcwfawuslapljbeljtisxnr` (`name`,`fieldId`),
  KEY `idx_lxkzfglaeskzxmzdmdvezhzxoysnosasjzwh` (`fieldId`),
  KEY `idx_vcuxrwjuzrkcurfrbewsxjywrwdmuyetksay` (`fieldLayoutId`),
  CONSTRAINT `fk_gyqhmelmxjhlmqjvelvkeebxpduldenmjwov` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_llhjdwagikmygjeaanponedjahrjfluctdvv` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `schemaVersion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `licenseKeyStatus` enum('valid','trial','invalid','mismatched','astray','unknown') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yisqxqlrqrhngswjlkagxyeyfhsbcbyxflvy` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfignames`
--

DROP TABLE IF EXISTS `projectconfignames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfignames` (
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_fsswmcjiazrrvyjrkgaoaouuvphqctgcauxy` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_bksbtvaimzsqzlcuxichoynihytoxhuefsze` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nurpeiyuprxkzrfaavddniuttdlvrflopwue` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_fspumabuswywijrhyfqilwakapyipdhzeqhh` (`sourceId`),
  KEY `idx_qtktgnhxhharjygihgcmcunnxetmngkphcsa` (`targetId`),
  KEY `idx_qquwjtwpaantjwcyitibvhowcxkiawqwbxii` (`sourceSiteId`),
  CONSTRAINT `fk_btedszlbaczmqrwusduxieqmnfhpvlmbkpmv` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rbflsdhgqvaavvrujgiunyikeveskzzoqqfl` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_scxxrozbpsmywzrikygpbwslfxhfvyeounwo` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xnzwwwgccuznyehhnxtbtlysqydoqvatlkvs` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sourceId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_joxnghqeqhkdgpwtbvueyjjwhdluhkhwjefm` (`sourceId`,`num`),
  KEY `fk_ucgiiunnnslgrmhyuidivjqxluvhofgjzraz` (`creatorId`),
  CONSTRAINT `fk_cejipwryemqspcvrtldinpvcahneatjvxswq` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ucgiiunnnslgrmhyuidivjqxluvhofgjzraz` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_etdxvxyiwsgioawphunxlqdnfolyfviybqod` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('single','channel','structure') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'all',
  `previewTargets` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qgozjsgadqsfuglcgdyyluncbjekfvyrhfmc` (`handle`),
  KEY `idx_frqrychyvljghdknlcvbgyddphxpzokryhbv` (`name`),
  KEY `idx_acaynmjpglmqipllswpwfpfwpyputzmjrade` (`structureId`),
  KEY `idx_jqouttvlpxdlvqpukycuirurtiikhmhecpzn` (`dateDeleted`),
  CONSTRAINT `fk_iymhmmvfemgzzbbswaifscmcsheymezeisbg` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text COLLATE utf8_unicode_ci,
  `template` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lnkphtmpuqixfzqpamhdomvxeuksjjykfraw` (`sectionId`,`siteId`),
  KEY `idx_wtzprcvyzkdzryeytilnwwxrpxyqxanaewjn` (`siteId`),
  CONSTRAINT `fk_dfqqffhrdsoturaahlelkqjtmiejmjicewko` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gosyleozkwizjrdwyineqhtcighwhwhkumkj` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `seomatic_metabundles`
--

DROP TABLE IF EXISTS `seomatic_metabundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seomatic_metabundles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `bundleVersion` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sourceBundleType` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sourceId` int(11) DEFAULT NULL,
  `sourceName` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sourceHandle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sourceType` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `typeId` int(11) DEFAULT NULL,
  `sourceTemplate` varchar(500) COLLATE utf8_unicode_ci DEFAULT '',
  `sourceSiteId` int(11) DEFAULT NULL,
  `sourceAltSiteSettings` text COLLATE utf8_unicode_ci,
  `sourceDateUpdated` datetime NOT NULL,
  `metaGlobalVars` text COLLATE utf8_unicode_ci,
  `metaSiteVars` text COLLATE utf8_unicode_ci,
  `metaSitemapVars` text COLLATE utf8_unicode_ci,
  `metaContainers` text COLLATE utf8_unicode_ci,
  `redirectsContainer` text COLLATE utf8_unicode_ci,
  `frontendTemplatesContainer` text COLLATE utf8_unicode_ci,
  `metaBundleSettings` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_ehlmpztjhtwebupfkmiuxmzyhqapfelxcxgx` (`sourceBundleType`),
  KEY `idx_jvjeocsgitgmwcobpeapoylusefyjcyaisec` (`sourceId`),
  KEY `idx_fqmvvbmxlyttymtwmctznepkrbytwuattvku` (`sourceSiteId`),
  KEY `idx_btrjbsryqpcuhqjjmqhqcfiiaktshbqwrnpi` (`sourceHandle`),
  CONSTRAINT `fk_gkzqbfqnshxbwrzptmgtlhoaewfsyvuwwqzx` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_buakjyogzaqkbsefbdoeiyjpbmgjwhhwlkpr` (`uid`),
  KEY `idx_spaunzcypftsbfnkajydgthvijlluwhtodfj` (`token`),
  KEY `idx_hqaaigtbvztxgfyeslqzepxllrjpzkhxypcs` (`dateUpdated`),
  KEY `idx_ddidpfszdyiueyracnsboatdcaqdlmguuwsk` (`userId`),
  CONSTRAINT `fk_pmvkkozagvmgzyzpfscewhbfvfcxckkwsoip` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kmgsyfxyuuesbtzesvgryzuqysqqfsutkzrs` (`userId`,`message`),
  CONSTRAINT `fk_qhtedfnkovrezpbxopnrwstdqpuubaiehsrw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yaqyboapsopxpvjysgdynouwluyakfwbyslm` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ueijaummhovzivqubllpjhrozrujuqwzxigb` (`dateDeleted`),
  KEY `idx_uitwfemwzsalhwmvskfvojublptuqiflruul` (`handle`),
  KEY `idx_fwspyevsemxluoffzfbdwfuknftxykhoblwh` (`sortOrder`),
  KEY `fk_ndxtkkxoxjapumneflxvlxgrszdilnejxsjz` (`groupId`),
  CONSTRAINT `fk_ndxtkkxoxjapumneflxvlxgrszdilnejxsjz` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_smxzvdupzkszhxrtireujlqdhqkdpdupmvrk` (`structureId`,`elementId`),
  KEY `idx_tbdgfpzhplppxrhfxwkzwmzggyqcrxltslzr` (`root`),
  KEY `idx_kagfkysdfgclgxtrrgtqlmnkzlomcqgdvums` (`lft`),
  KEY `idx_glklpamygsxusadsfhuwfcvdymcnhgokzhjh` (`rgt`),
  KEY `idx_lnizajrsdtajdyiteslopkgxbadzzacdlwdx` (`level`),
  KEY `idx_aseoiqedbvdtkwdcjflhxndxkmuztfvvfpwo` (`elementId`),
  CONSTRAINT `fk_cujncmsqdzuqycvgqicarcougmfabgboacwa` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hzuwmoqpjaiquysjkzgvfqykzmevghzjibci` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ksodpcrqplxdrnqhqzapoekzolbylbfikwly` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subject` text COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rxuflsaucanodlaimkllhpwrzohanwwpaisc` (`key`,`language`),
  KEY `idx_cyfwtejixnedupjvjihizeanjlkodjrpqfrp` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xecvsgujqmzxxbcqsjrkqevhhwstunraqlnm` (`name`),
  KEY `idx_wzoanuvmexblsxjsyvzpayrhqnjfvmhckdlk` (`handle`),
  KEY `idx_jhdybumcxclcsbqbocumwwsmlvbxcjlzalpm` (`dateDeleted`),
  KEY `fk_fxquetapyxvoqfnfqmkigtzfllegesuznjxf` (`fieldLayoutId`),
  CONSTRAINT `fk_fxquetapyxvoqfnfqmkigtzfllegesuznjxf` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qnutfzonmeyusiyclswnuwdtwmrfnofhityh` (`groupId`),
  CONSTRAINT `fk_proeikrrxhdfbegsssdoghynzlirncddissy` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sshyohhixvwgtukvkfjpowjjxrigbcedmvpe` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecacheelements`
--

DROP TABLE IF EXISTS `templatecacheelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecacheelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_wgfdgykagwjolfkrgzgehkulxizadzkiwhla` (`cacheId`),
  KEY `idx_qisquxufrwvwvccivmiyllkyxrdgdikbyyub` (`elementId`),
  CONSTRAINT `fk_avtavhedskvprldeywmscfkdtghrnlhhroda` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_baaklfvkhgdgmahwrdzgvrjugqrzaksrsoqr` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecachequeries`
--

DROP TABLE IF EXISTS `templatecachequeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecachequeries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `query` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_wuqmqmtbbournxqkvdcltppkxovqwulpcsga` (`cacheId`),
  KEY `idx_wvbdbdvievnanwsyzocqfrmbkveqqeboxtvk` (`type`),
  CONSTRAINT `fk_vrjbydhsjmdyrmblpzfmhcjayrzttmpmekcm` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecaches`
--

DROP TABLE IF EXISTS `templatecaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) NOT NULL,
  `cacheKey` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_npksdxygniqidvsltwuvguccjprslttbebpr` (`cacheKey`,`siteId`,`expiryDate`,`path`),
  KEY `idx_rbbsfaiyzjpbekasrprkukeeyznxlzfkycry` (`cacheKey`,`siteId`,`expiryDate`),
  KEY `idx_vkjpbrqaoivvsxcqoyhfxzdwogsdzdfqbiif` (`siteId`),
  CONSTRAINT `fk_gvruzpuasygnbcnmeatalneofforifgfmyna` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `route` text COLLATE utf8_unicode_ci,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_flbpugvfmuhwcwdvpcdtmhjghcygvhlqwgmm` (`token`),
  KEY `idx_ofdudiqrtnqxeqdhiudrhncazqumcdwavlwd` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wyrsoxjzrokzjheqrlatfegrmocczumqntkz` (`handle`),
  KEY `idx_enkkfgjgybedjikthnscvehhfpsxqkaducaz` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_iqloktprlvbrwfoyogijqkxszhbsnacrwssw` (`groupId`,`userId`),
  KEY `idx_jejeuaarmjaicllzkuptwrzarbugjodrsjuf` (`userId`),
  CONSTRAINT `fk_qzommzbegtsuddtsistcdzeidvrspomaykhp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ymgreuwzhqxbuxdfyxwvdtygzidbfayduork` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vaivrnjgatmubjnyqntnywhyigqduxqnivap` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_prwkyldbhmitjavmuypucgmggohufyfcvign` (`permissionId`,`groupId`),
  KEY `idx_kccrjdeswhktkcktvxitfvoadrlbqjzzazdb` (`groupId`),
  CONSTRAINT `fk_hyzoeopafjufnflmngiwmdkeevrmcrmixijh` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vnjombaezyzdlfudznopesjxzdpfgpgpyozt` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gkampyturrhmltdbkyecyxlcybcbjpyvpjvy` (`permissionId`,`userId`),
  KEY `idx_qmyghaqxnzqnpqfvntyywszvexzarmdpkmxl` (`userId`),
  CONSTRAINT `fk_jqwcfmdmfyuwbjfkzhvkgogykmzzywfqotdw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_msbwkkmvdsqlsmpefpqkfdslxnrapltjqrzz` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_lllymbuhvyawerixeogjcbyaecwcsfmxdlse` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `firstName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cqtcfczcsjwjseotbiqvicnffybyvaoldcop` (`uid`),
  KEY `idx_lrxxnevcimszcepqlcdirculmcysihkxbwbw` (`verificationCode`),
  KEY `idx_onleiodkpbdjwfqrtixxqtvevvtqkjfwxfye` (`email`),
  KEY `idx_tlngcrmeshhcrstmqbffqpuycymrwxpsvsqd` (`username`),
  KEY `fk_oppoexukmroyqqokqfsrvkiqcotgfctoutww` (`photoId`),
  CONSTRAINT `fk_oppoexukmroyqqokqfsrvkiqcotgfctoutww` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_yvvbivhpwuuckuphzqibmfbqjueydbddyvkd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_webivsuzrpkekweterhglpycbggyhmtztdet` (`name`,`parentId`,`volumeId`),
  KEY `idx_avicwlrvjhzhoqswlfsyxbvdxuucmcszncka` (`parentId`),
  KEY `idx_mnukhjpkaieidewtjxuyxufwrwimmqgvhvey` (`volumeId`),
  CONSTRAINT `fk_ndmtmoxnoodcjrpdaadaqdkivbmptyyxtxme` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xhomzqzcjrcrnyummssqnhpjqsgdonbzwmuu` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `titleTranslationMethod` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text COLLATE utf8_unicode_ci,
  `settings` text COLLATE utf8_unicode_ci,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bdutxrvcanllfzjrzqrqhttqvakmfvabqhod` (`name`),
  KEY `idx_zrevaxmtdhfgvhfszrcyxbvgftgwwtthrhvu` (`handle`),
  KEY `idx_xhgsltoyrqobwznknhakwrqeibuvkepnimeh` (`fieldLayoutId`),
  KEY `idx_jckgofjojchdymytgsncdsgmvdpenqkzxxuw` (`dateDeleted`),
  CONSTRAINT `fk_gjaolzwgvjefcnbduyahxnsckzuzgrwyyajq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ixyqwbdwfukawvnlltympdjdpvfrlxcwvsqe` (`userId`),
  CONSTRAINT `fk_olstvyprhvfakesmropulhbhbeinfpddrnda` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'aethon'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-26 22:18:08
-- MariaDB dump 10.19  Distrib 10.5.9-MariaDB, for Linux (x86_64)
--
-- Host: mysql-5.7-3306.database.nitro    Database: aethon
-- ------------------------------------------------------
-- Server version	5.7.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assettransforms`
--

LOCK TABLES `assettransforms` WRITE;
/*!40000 ALTER TABLE `assettransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assettransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `contactform_submissions`
--

LOCK TABLES `contactform_submissions` WRITE;
/*!40000 ALTER TABLE `contactform_submissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `contactform_submissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `content` VALUES (1,1,1,NULL,'2021-04-26 17:22:35','2021-04-26 17:22:35','ff4fce73-042f-4507-9c24-e11f1c34512d'),(2,2,1,'Home','2021-04-26 19:10:49','2021-04-26 19:10:49','89d3a488-17b0-4304-b8cb-bccc38fc0cb8'),(3,3,1,'Home','2021-04-26 19:10:49','2021-04-26 19:10:49','baa015d5-9d88-4f47-a882-2bf4a01dde40');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementindexsettings`
--

LOCK TABLES `elementindexsettings` WRITE;
/*!40000 ALTER TABLE `elementindexsettings` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elementindexsettings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2021-04-26 17:22:35','2021-04-26 17:22:35',NULL,'2e1033ba-0a96-4c8e-bdb6-9c930d50a087'),(2,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2021-04-26 19:10:49','2021-04-26 19:10:49',NULL,'bdf05d29-957d-4e56-a973-caaa0f5710d7'),(3,NULL,1,1,'craft\\elements\\Entry',1,0,'2021-04-26 19:10:49','2021-04-26 19:10:49',NULL,'6a9ab09e-0559-4ad2-a31f-990a47d67c6e');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2021-04-26 17:22:35','2021-04-26 17:22:35','9194cb2f-9885-4be5-9ad8-0534e6bd238d'),(2,2,1,'home','__home__',1,'2021-04-26 19:10:49','2021-04-26 19:10:49','4209ecef-8fe1-4df0-939e-b694c9a2612e'),(3,3,1,'home','__home__',1,'2021-04-26 19:10:49','2021-04-26 19:10:49','53a90caa-e349-43b6-8ec9-208c1fcfd7b7');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (2,1,NULL,1,NULL,'2021-04-26 19:10:00',NULL,NULL,'2021-04-26 19:10:49','2021-04-26 19:10:49','cfea5b61-38d6-4475-a571-550ed9da4ee4'),(3,1,NULL,1,NULL,'2021-04-26 19:10:00',NULL,NULL,'2021-04-26 19:10:49','2021-04-26 19:10:49','927b9b75-b1d3-446e-8edd-0ab2dc20110a');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,1,'Home','home',0,'site',NULL,'{section.name|raw}',1,'2021-04-26 19:10:49','2021-04-26 19:10:49',NULL,'0cc347c2-5aaa-4dbf-be01-15ca4e30e362');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldgroups` VALUES (1,'Common','2021-04-26 17:22:34','2021-04-26 17:22:34',NULL,'c7c37252-7715-4730-af7f-51d0ef0c84a6');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','2021-04-26 19:10:49','2021-04-26 19:10:49',NULL,'9880c4fc-b0c5-4117-b40c-01d6a44c89e3');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouttabs` VALUES (1,1,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100}]',1,'2021-04-26 19:10:49','2021-04-26 19:10:49','50dc77d7-56ea-457e-a7be-6e6200a7c5d1');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'3.6.12','3.6.8',0,'dghvwpejqkcm','ixxaochvtseq','2021-04-26 17:22:34','2021-04-26 22:17:42','30733d7e-21dc-4848-9204-77b8005ea6d5');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,'craft','Install','2021-04-26 17:22:35','2021-04-26 17:22:35','2021-04-26 17:22:35','dcb28716-4eab-4d85-8b69-35f6c35272a3'),(2,'craft','m150403_183908_migrations_table_changes','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','834470f7-b098-4c13-868a-fd6bb4568caf'),(3,'craft','m150403_184247_plugins_table_changes','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','f6037308-db89-4e66-85c0-3928dc780aac'),(4,'craft','m150403_184533_field_version','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','cc0ec5f6-6b09-4b33-afcd-9f0df2e1cb33'),(5,'craft','m150403_184729_type_columns','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','781d30ee-25ac-408a-ad23-26dda169a52d'),(6,'craft','m150403_185142_volumes','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','90642219-fa03-4b45-b50a-817af216dc6c'),(7,'craft','m150428_231346_userpreferences','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','3196d1d9-8635-4d92-bbf3-9bb9a36fbfab'),(8,'craft','m150519_150900_fieldversion_conversion','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','47d58f47-3dfa-4111-b456-2fe33be3a928'),(9,'craft','m150617_213829_update_email_settings','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','00cc1fd7-46f3-4828-a681-3d2cb64f42b0'),(10,'craft','m150721_124739_templatecachequeries','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','5f51c92d-704b-49bc-8f4e-f0e0e6572458'),(11,'craft','m150724_140822_adjust_quality_settings','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','9f5c9517-911b-4efb-9c5a-0c6d7a3d76f2'),(12,'craft','m150815_133521_last_login_attempt_ip','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','1fb2689d-d7c3-4252-9c4a-388148410c7f'),(13,'craft','m151002_095935_volume_cache_settings','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','a60f683c-3097-408b-b6c1-9babcf83ab0e'),(14,'craft','m151005_142750_volume_s3_storage_settings','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','e4db078e-100f-49e6-ba5d-a08382b7f859'),(15,'craft','m151016_133600_delete_asset_thumbnails','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','3e3137a4-af83-44a7-bee9-662fc393299a'),(16,'craft','m151209_000000_move_logo','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','08a2c669-1771-47dc-bcc2-3bff09ada44a'),(17,'craft','m151211_000000_rename_fileId_to_assetId','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','70e2a795-d237-4b20-9837-c6fd0ba39268'),(18,'craft','m151215_000000_rename_asset_permissions','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','d0ffed4b-882f-405e-ae20-9b639d3d0eb4'),(19,'craft','m160707_000001_rename_richtext_assetsource_setting','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','88e4010c-17c8-4a62-b3f8-893828ca37ef'),(20,'craft','m160708_185142_volume_hasUrls_setting','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','53bf4eae-1a1e-48a4-b599-9bb2f119209c'),(21,'craft','m160714_000000_increase_max_asset_filesize','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','382bb42b-b010-4923-b058-ff1a1a459203'),(22,'craft','m160727_194637_column_cleanup','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','398b5aaf-351f-4b6f-913d-8bc0387bd042'),(23,'craft','m160804_110002_userphotos_to_assets','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','21a27943-61b1-4ead-ada9-a54ecb3f86ae'),(24,'craft','m160807_144858_sites','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','21491945-864e-44e5-a094-04b69ea10b1e'),(25,'craft','m160829_000000_pending_user_content_cleanup','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','08113c5d-31af-436d-8cd9-511ac37bec9c'),(26,'craft','m160830_000000_asset_index_uri_increase','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','770f0ed6-5627-40ab-866b-cbb3c6a539ac'),(27,'craft','m160912_230520_require_entry_type_id','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','10515263-a7ca-499f-bd99-b12fd4bb6cb6'),(28,'craft','m160913_134730_require_matrix_block_type_id','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','0685e040-6297-4a10-beb5-87b36a96624d'),(29,'craft','m160920_174553_matrixblocks_owner_site_id_nullable','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','e7f04f9a-2834-4e92-96dd-4c487d68d968'),(30,'craft','m160920_231045_usergroup_handle_title_unique','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','b8b2c794-3d5e-44f6-bd04-102c6fa4d494'),(31,'craft','m160925_113941_route_uri_parts','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','900fd3f5-df32-441c-adaa-ae69cd1f49e8'),(32,'craft','m161006_205918_schemaVersion_not_null','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','b553e6d5-f411-41a0-86db-7ae7066f3b8d'),(33,'craft','m161007_130653_update_email_settings','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','eddf755d-7694-4715-ab75-64d9b50a8788'),(34,'craft','m161013_175052_newParentId','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','15aa91eb-731d-480b-af42-7bc4d11bc4fb'),(35,'craft','m161021_102916_fix_recent_entries_widgets','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','6bd3beb1-377b-4389-ad08-90bea4684e00'),(36,'craft','m161021_182140_rename_get_help_widget','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','6fa34465-d087-4fef-a374-9d43f047ac02'),(37,'craft','m161025_000000_fix_char_columns','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','8c5ebd80-239d-4529-af70-a4b02e31c1b7'),(38,'craft','m161029_124145_email_message_languages','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','0e95667d-a0df-4702-bf43-e3616e72e165'),(39,'craft','m161108_000000_new_version_format','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','6b960377-d063-4d0f-89ad-8ea93229a633'),(40,'craft','m161109_000000_index_shuffle','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','101aeb24-b4ee-4890-b5ed-ee1f10bbc84a'),(41,'craft','m161122_185500_no_craft_app','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','0709edec-3d63-4a8b-b6d7-4e61af7f6e83'),(42,'craft','m161125_150752_clear_urlmanager_cache','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','576529e2-7174-4784-8024-3102e3f46430'),(43,'craft','m161220_000000_volumes_hasurl_notnull','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','b706c4c0-2d83-4c79-8baa-efc4cea8a312'),(44,'craft','m170114_161144_udates_permission','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','9f98e36a-f5f0-4ab1-93bc-d51bc086d711'),(45,'craft','m170120_000000_schema_cleanup','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','2cdaf6e5-2502-4d09-b3c1-2540b25fc9fd'),(46,'craft','m170126_000000_assets_focal_point','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','172998e3-d0f4-4922-99f5-15f1a7fa3484'),(47,'craft','m170206_142126_system_name','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','58568d9e-d2c7-4bc6-bb5c-43270cdb131b'),(48,'craft','m170217_044740_category_branch_limits','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','82449cc9-cce0-482f-8299-7ccd1957651d'),(49,'craft','m170217_120224_asset_indexing_columns','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','046456a2-1abf-4a06-a695-7582d61eaf41'),(50,'craft','m170223_224012_plain_text_settings','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','36c80623-1355-4a0f-b7df-4d8360a7b1b5'),(51,'craft','m170227_120814_focal_point_percentage','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','724c5012-7cb6-4afa-baf7-c2435f4dcc59'),(52,'craft','m170228_171113_system_messages','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','7c17fd6c-9985-4271-a268-85d0c8504dd0'),(53,'craft','m170303_140500_asset_field_source_settings','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','cce163f6-6e62-4507-9613-61986c9a7e21'),(54,'craft','m170306_150500_asset_temporary_uploads','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','1cf4a402-6b5b-4996-80af-abb7db43e88d'),(55,'craft','m170523_190652_element_field_layout_ids','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','3d8cb592-a38f-4d47-9586-ae64fbac769d'),(56,'craft','m170621_195237_format_plugin_handles','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','e859db7a-cad4-40d3-a4e9-b3c5059f758c'),(57,'craft','m170630_161027_deprecation_line_nullable','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','46f5f5b9-71a8-48b5-98f5-c574e992fb33'),(58,'craft','m170630_161028_deprecation_changes','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','c6ae2282-2d49-4296-ae32-5665a6471228'),(59,'craft','m170703_181539_plugins_table_tweaks','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','d729c5b6-649f-4dc0-af87-84c217a59f64'),(60,'craft','m170704_134916_sites_tables','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','d9d57b31-a346-42ca-a3d2-93146a45f4cc'),(61,'craft','m170706_183216_rename_sequences','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','04f76774-fd81-417c-9e67-f87af5370350'),(62,'craft','m170707_094758_delete_compiled_traits','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','b0919574-9877-4aa3-b28a-64cbbd8d18c3'),(63,'craft','m170731_190138_drop_asset_packagist','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','5b0ae875-e01a-4cf8-ba68-9e15923b0aff'),(64,'craft','m170810_201318_create_queue_table','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','4d064814-8dec-4e63-a0f7-6aacffa3c67c'),(65,'craft','m170903_192801_longblob_for_queue_jobs','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','8f566827-a3a4-40a4-b12d-c5b2b432998b'),(66,'craft','m170914_204621_asset_cache_shuffle','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','fc0ef860-be1b-4299-8459-2c66a3dad7c9'),(67,'craft','m171011_214115_site_groups','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','65d3a118-0bbd-4333-8a9b-f46ff7a874e3'),(68,'craft','m171012_151440_primary_site','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','d628cbdf-43c8-40b9-97da-588fb334b8ad'),(69,'craft','m171013_142500_transform_interlace','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','f46dc5b5-0778-44a8-a9d9-df76c4f08e7a'),(70,'craft','m171016_092553_drop_position_select','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','aa256c20-a27e-475a-a617-6ca870b2e8a7'),(71,'craft','m171016_221244_less_strict_translation_method','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','67ec59c4-d95a-4623-a3ff-1551dd4d670a'),(72,'craft','m171107_000000_assign_group_permissions','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','51f8d0d6-9e5c-4ecf-98ab-ca636767335c'),(73,'craft','m171117_000001_templatecache_index_tune','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','5d57be04-0c17-4101-93dc-9708d998be20'),(74,'craft','m171126_105927_disabled_plugins','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','9320efea-87f1-421f-bfc8-b5c4ef5c2bda'),(75,'craft','m171130_214407_craftidtokens_table','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','b14437e4-abab-4627-87ca-2861cfc62956'),(76,'craft','m171202_004225_update_email_settings','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','dc418870-6583-4dd6-8c95-873120f55081'),(77,'craft','m171204_000001_templatecache_index_tune_deux','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','b6164afa-a7ba-4123-8250-f5aab4fdcd09'),(78,'craft','m171205_130908_remove_craftidtokens_refreshtoken_column','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','26b5225a-89ae-436f-918a-8ca7c535c002'),(79,'craft','m171218_143135_longtext_query_column','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','02e070d8-1d64-468d-8166-98ae6f281e36'),(80,'craft','m171231_055546_environment_variables_to_aliases','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','020d3a64-9b4b-4f6c-a058-1087f3c1d91e'),(81,'craft','m180113_153740_drop_users_archived_column','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','b0942de0-cc37-48ec-a00d-a848ab40cb88'),(82,'craft','m180122_213433_propagate_entries_setting','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','cbf02522-d1ff-4511-96f2-2738b272ab0a'),(83,'craft','m180124_230459_fix_propagate_entries_values','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','55f98652-e82d-47d7-85a0-1be9e6fff424'),(84,'craft','m180128_235202_set_tag_slugs','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','ee7aa90f-ac8e-425c-bfdf-fc4f8ae6c538'),(85,'craft','m180202_185551_fix_focal_points','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','4e55d651-887e-4c1b-beaa-bec8f481d3b7'),(86,'craft','m180217_172123_tiny_ints','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','9197171c-4162-4fb8-9564-38d35acf8624'),(87,'craft','m180321_233505_small_ints','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','d315945c-d751-4379-909a-a439ef510960'),(88,'craft','m180404_182320_edition_changes','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','9295a60b-37a4-41c7-9c76-db057fb036d3'),(89,'craft','m180411_102218_fix_db_routes','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','389029ac-2316-43e9-9e54-4381b58e2da5'),(90,'craft','m180416_205628_resourcepaths_table','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','751ad36b-3010-42be-b134-448e0b4a8ae5'),(91,'craft','m180418_205713_widget_cleanup','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','8cfd1f8d-a292-421b-83e4-0fa48d95f6fe'),(92,'craft','m180425_203349_searchable_fields','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','3f67d94f-8709-457e-a4a0-c84beb0d1f9b'),(93,'craft','m180516_153000_uids_in_field_settings','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','21323fc6-3131-47e2-a46d-18553dbf79e7'),(94,'craft','m180517_173000_user_photo_volume_to_uid','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','0ca57b39-13a7-452f-b4a6-77c1342a6ce7'),(95,'craft','m180518_173000_permissions_to_uid','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','b5173e59-ef7d-446d-b99c-7efbda36aef3'),(96,'craft','m180520_173000_matrix_context_to_uids','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','c3456ced-e29b-4c84-96ce-c52a55a61eee'),(97,'craft','m180521_172900_project_config_table','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','5d7ac6f9-f1ed-4acc-b85d-4e6c5b435667'),(98,'craft','m180521_173000_initial_yml_and_snapshot','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','506685fd-7a6e-4797-a92a-610a92569402'),(99,'craft','m180731_162030_soft_delete_sites','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','1b851ef3-0474-43f4-9266-1c7e8ebca4bb'),(100,'craft','m180810_214427_soft_delete_field_layouts','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','1f1219a9-1a41-4973-b8d3-12152a23964f'),(101,'craft','m180810_214439_soft_delete_elements','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','86aec971-47a6-4860-9e88-f92add7b739a'),(102,'craft','m180824_193422_case_sensitivity_fixes','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','7ea92358-7312-47da-a0a5-194705c610b8'),(103,'craft','m180901_151639_fix_matrixcontent_tables','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','ca856af0-5972-4ed2-b86c-84289c6a7ec1'),(104,'craft','m180904_112109_permission_changes','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','ed1023e4-5f73-42f8-8270-e07975f20725'),(105,'craft','m180910_142030_soft_delete_sitegroups','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','070e74cd-17e9-43c5-8dcb-551bf5ea9eb2'),(106,'craft','m181011_160000_soft_delete_asset_support','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','a84b036f-be4e-4fea-9a69-f65c385f7667'),(107,'craft','m181016_183648_set_default_user_settings','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','9ffb14aa-cc3e-4116-acaf-9f9d33146d7d'),(108,'craft','m181017_225222_system_config_settings','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','a07d744e-da1a-43d4-88dc-d49ab860eeee'),(109,'craft','m181018_222343_drop_userpermissions_from_config','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','c0562117-450f-4b85-bb45-aeb70e5acd6d'),(110,'craft','m181029_130000_add_transforms_routes_to_config','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','e63014ce-2d31-4c10-af73-7bc4ea841e53'),(111,'craft','m181112_203955_sequences_table','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','09795dae-bce0-40e2-9561-fbb0cd6a9ec1'),(112,'craft','m181121_001712_cleanup_field_configs','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','d18b95ef-37e4-4807-8b73-6a00e0af7cc3'),(113,'craft','m181128_193942_fix_project_config','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','5df99558-f68c-487c-a882-04db47d77843'),(114,'craft','m181130_143040_fix_schema_version','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','3570c6a1-4ea1-46e6-a428-0a8ef6d4b9dc'),(115,'craft','m181211_143040_fix_entry_type_uids','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','76f20558-685c-4299-adb7-b50747a44404'),(116,'craft','m181217_153000_fix_structure_uids','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','79b5c84f-a743-4fba-9bac-3ef16fb576a9'),(117,'craft','m190104_152725_store_licensed_plugin_editions','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','4f65d045-8354-4fed-ae03-62e0a7f0118f'),(118,'craft','m190108_110000_cleanup_project_config','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','32f079c3-b7e3-4bea-86bb-6e809aecd01f'),(119,'craft','m190108_113000_asset_field_setting_change','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','1fdca9ce-3f32-4761-b846-bc368788e3bd'),(120,'craft','m190109_172845_fix_colspan','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','09b3aedc-5c7d-4ee4-a9ae-a6e2677460d7'),(121,'craft','m190110_150000_prune_nonexisting_sites','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','a58a9157-7953-4d87-b7ba-da627695c81e'),(122,'craft','m190110_214819_soft_delete_volumes','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','1ef30423-23dc-4fa5-ab6a-c8d3a5d8d7f6'),(123,'craft','m190112_124737_fix_user_settings','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','1ecaffc4-25b1-4b95-9f39-010de5176bb3'),(124,'craft','m190112_131225_fix_field_layouts','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','6c36e29c-d78d-4978-a0e4-d7b7c0dfda2a'),(125,'craft','m190112_201010_more_soft_deletes','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','75355975-590c-486d-ab37-10ea49b1dc9c'),(126,'craft','m190114_143000_more_asset_field_setting_changes','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','2f4b7cda-e99d-486f-94e7-5c6863ccd970'),(127,'craft','m190121_120000_rich_text_config_setting','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','fadd6ca8-b397-4ae0-a798-f5e8b09ba68f'),(128,'craft','m190125_191628_fix_email_transport_password','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','76909766-bf25-4188-ae18-ab86446c052c'),(129,'craft','m190128_181422_cleanup_volume_folders','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','271a3b0e-3d5e-4731-82f3-0cc2fbfb2dc7'),(130,'craft','m190205_140000_fix_asset_soft_delete_index','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','7d614bd4-38ef-4acc-b1b0-0c652741a266'),(131,'craft','m190218_143000_element_index_settings_uid','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','25fc2df1-044f-4532-b06b-f46c6d0ee3b2'),(132,'craft','m190312_152740_element_revisions','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','ad44e665-ed68-42dd-b0e0-1152020c70b5'),(133,'craft','m190327_235137_propagation_method','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','feea248b-6601-4a16-99c1-852df1002a73'),(134,'craft','m190401_223843_drop_old_indexes','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','47849eb1-6c4f-42c5-88df-617c98f69b8b'),(135,'craft','m190416_014525_drop_unique_global_indexes','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','eb81069d-731b-4b87-91e9-f47dde89fa53'),(136,'craft','m190417_085010_add_image_editor_permissions','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','35feb8b3-37d2-4a1e-8433-a236d866b5c2'),(137,'craft','m190502_122019_store_default_user_group_uid','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','073b32c9-5138-4a0d-a695-e9df2e35ec96'),(138,'craft','m190504_150349_preview_targets','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','1d1b8526-5716-4e36-ac7b-1c39154022b0'),(139,'craft','m190516_184711_job_progress_label','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','05dcf27e-cd48-47ec-9aae-9d6aa27b872b'),(140,'craft','m190523_190303_optional_revision_creators','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','349f6007-7e35-4ec0-bdd3-402fd6abe2df'),(141,'craft','m190529_204501_fix_duplicate_uids','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','4725d758-7964-40df-bd9d-ed187ccb4835'),(142,'craft','m190605_223807_unsaved_drafts','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','831eb6e1-c4c3-43fa-b9d8-f1c96b4e85b1'),(143,'craft','m190607_230042_entry_revision_error_tables','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','c1dee415-563a-4d86-a219-b8b59891addc'),(144,'craft','m190608_033429_drop_elements_uid_idx','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','364196ae-58ea-4ba7-8d5c-72cd0145d807'),(145,'craft','m190617_164400_add_gqlschemas_table','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','7f7ece14-d9eb-4dd3-a169-84a75bbb8590'),(146,'craft','m190624_234204_matrix_propagation_method','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','2dd6517c-606d-4b28-83a9-a552bd79f2a0'),(147,'craft','m190711_153020_drop_snapshots','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','44b77955-8f89-4908-b17c-676fe55c7e93'),(148,'craft','m190712_195914_no_draft_revisions','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','6cdb7ec1-409d-4953-a0f4-49785c14ab42'),(149,'craft','m190723_140314_fix_preview_targets_column','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','f3052668-35c6-43bb-80e1-9913dd77224d'),(150,'craft','m190820_003519_flush_compiled_templates','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','7a3a1d6d-3c1a-455d-9758-8e9b8fe41682'),(151,'craft','m190823_020339_optional_draft_creators','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','e2aca1f5-8149-4d38-ba3f-8da2a407fd18'),(152,'craft','m190913_152146_update_preview_targets','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','22ece585-5e16-4b4d-b9b6-3a39103d9d75'),(153,'craft','m191107_122000_add_gql_project_config_support','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','9d3011a0-eabb-49e9-ab11-6c7f500c1fe2'),(154,'craft','m191204_085100_pack_savable_component_settings','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','f215419a-74bf-40db-9f6f-44343e4b2fb7'),(155,'craft','m191206_001148_change_tracking','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','c3e9f455-d7be-4ebd-af91-4a9ae981197e'),(156,'craft','m191216_191635_asset_upload_tracking','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','550e421a-5d38-41df-aa8a-ccde18c0467d'),(157,'craft','m191222_002848_peer_asset_permissions','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','2c53d82c-c0ad-4876-a7a6-71f4721a856b'),(158,'craft','m200127_172522_queue_channels','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','659465a4-617a-4093-915c-d0477df365e1'),(159,'craft','m200211_175048_truncate_element_query_cache','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','c871f352-c678-44e7-9759-e0a220237bd9'),(160,'craft','m200213_172522_new_elements_index','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','197af09b-1f63-449f-a6cc-0cb506c24ed9'),(161,'craft','m200228_195211_long_deprecation_messages','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','6a359c22-1c72-4486-83e4-2a6746062330'),(162,'craft','m200306_054652_disabled_sites','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','34221eba-66be-4419-abc3-7f1675228da3'),(163,'craft','m200522_191453_clear_template_caches','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','269111fe-fe19-400c-a7ba-68254c12c06d'),(164,'craft','m200606_231117_migration_tracks','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','f0b59158-767a-4c4d-a2c9-2b328515e350'),(165,'craft','m200619_215137_title_translation_method','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','13898464-5407-4d5a-9a63-86d9d658b961'),(166,'craft','m200620_005028_user_group_descriptions','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','a4f7348e-1748-43c2-8f9c-f9d71caca243'),(167,'craft','m200620_230205_field_layout_changes','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','41606139-4038-42d7-b96a-7ee7efe945d8'),(168,'craft','m200625_131100_move_entrytypes_to_top_project_config','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','941fde70-c457-4444-ab1b-335d2c951a80'),(169,'craft','m200629_112700_remove_project_config_legacy_files','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','473246e0-f251-41ad-8e2c-055ed5b217ce'),(170,'craft','m200630_183000_drop_configmap','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','a93251fb-fdfa-4b9a-9c6d-ce191078aede'),(171,'craft','m200715_113400_transform_index_error_flag','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','123c77f3-b9ab-40bc-8087-5dd0ebb1e918'),(172,'craft','m200716_110900_replace_file_asset_permissions','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','a4b2c1cc-3031-4489-bbd7-2728b24e53a6'),(173,'craft','m200716_153800_public_token_settings_in_project_config','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','168e78d7-7fa1-4a7a-b118-ef43fc78f77f'),(174,'craft','m200720_175543_drop_unique_constraints','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','c5d0c570-270b-4e3b-b582-47d264fc301f'),(175,'craft','m200825_051217_project_config_version','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','48891946-429f-4e85-8415-db8372c22dd6'),(176,'craft','m201116_190500_asset_title_translation_method','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','b9a4ac26-c0a6-4381-b9c9-cdbd12581995'),(177,'craft','m201124_003555_plugin_trials','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','670ee313-0d27-47aa-ba19-a3c7db1bee91'),(178,'craft','m210209_135503_soft_delete_field_groups','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','18890f77-c693-4c73-8561-5c8603777595'),(179,'craft','m210212_223539_delete_invalid_drafts','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','16215727-a760-419f-928c-a55f0e26ca72'),(180,'craft','m210214_202731_track_saved_drafts','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','a58e3663-f4c7-4312-ada6-cf779941c8c5'),(181,'craft','m210223_150900_add_new_element_gql_schema_components','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','6a7c5eed-a954-454b-8766-a5d500a49242'),(182,'craft','m210224_162000_add_projectconfignames_table','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','f9d0c337-096a-4b6c-994a-e2e37c88a8e4'),(183,'craft','m210326_132000_invalidate_projectconfig_cache','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','27888458-7116-4303-a00b-f87d2c26dbd6'),(184,'craft','m210331_220322_null_author','2021-04-26 17:22:36','2021-04-26 17:22:36','2021-04-26 17:22:36','97b1066f-ed45-4941-b016-7a699fd26760'),(185,'plugin:linkit','Install','2021-04-26 21:59:54','2021-04-26 21:59:54','2021-04-26 21:59:54','ecc57e20-d5a2-48b1-bade-22c6615bfb21'),(186,'plugin:linkit','m180423_175007_linkit_craft2','2021-04-26 21:59:54','2021-04-26 21:59:54','2021-04-26 21:59:54','cd6fc9c4-f7f7-4adf-aa85-025534595c46'),(187,'plugin:redactor','m180430_204710_remove_old_plugins','2021-04-26 22:07:08','2021-04-26 22:07:08','2021-04-26 22:07:08','426ec581-11c7-4406-9578-4486d7fb5acd'),(188,'plugin:redactor','Install','2021-04-26 22:07:08','2021-04-26 22:07:08','2021-04-26 22:07:08','5500f10a-b8f2-4942-8df3-ac962667bd37'),(189,'plugin:redactor','m190225_003922_split_cleanup_html_settings','2021-04-26 22:07:08','2021-04-26 22:07:08','2021-04-26 22:07:08','0f9d0705-265a-4431-a65c-e228e9c5fdbc'),(190,'plugin:neo','Install','2021-04-26 22:08:02','2021-04-26 22:08:02','2021-04-26 22:08:02','4de44b15-3fa7-4759-9005-dfaa741f9ada'),(191,'plugin:neo','m181022_123749_craft3_upgrade','2021-04-26 22:08:02','2021-04-26 22:08:02','2021-04-26 22:08:02','0174f96c-25ce-4b3c-a537-1eea461f5160'),(192,'plugin:neo','m190127_023247_soft_delete_compatibility','2021-04-26 22:08:02','2021-04-26 22:08:02','2021-04-26 22:08:02','bcce4899-a104-4826-94b3-d2d233dc3720'),(193,'plugin:neo','m200313_015120_structure_update','2021-04-26 22:08:02','2021-04-26 22:08:02','2021-04-26 22:08:02','e5c9d637-a8db-4173-b343-32fd03d67f93'),(194,'plugin:neo','m200722_061114_add_max_sibling_blocks','2021-04-26 22:08:02','2021-04-26 22:08:02','2021-04-26 22:08:02','fe149d76-2920-4879-bd85-73c3e209b9b3'),(195,'plugin:neo','m201108_123758_block_propagation_method_fix','2021-04-26 22:08:02','2021-04-26 22:08:02','2021-04-26 22:08:02','b66b61fb-5c69-43b8-9ad8-75e792d09de0'),(196,'plugin:neo','m201208_110049_delete_blocks_without_sort_order','2021-04-26 22:08:02','2021-04-26 22:08:02','2021-04-26 22:08:02','15d801da-d873-40e3-8f0a-7efe664a5b2b'),(197,'plugin:neo','m201223_024137_delete_blocks_with_invalid_owner','2021-04-26 22:08:02','2021-04-26 22:08:02','2021-04-26 22:08:02','303093b4-97b1-493f-8f92-b5871b71e332'),(198,'plugin:contact-form-extensions','Install','2021-04-26 22:10:28','2021-04-26 22:10:28','2021-04-26 22:10:28','da406a4b-d917-4584-80d9-9fef56f85e2b'),(199,'plugin:seomatic','Install','2021-04-26 22:11:56','2021-04-26 22:11:56','2021-04-26 22:11:56','2880f3a7-095a-46f1-9c20-61d62de52cca'),(200,'plugin:seomatic','m180314_002755_field_type','2021-04-26 22:11:56','2021-04-26 22:11:56','2021-04-26 22:11:56','d842a0c0-9ca7-4030-99ae-731679a5fa1b'),(201,'plugin:seomatic','m180314_002756_base_install','2021-04-26 22:11:56','2021-04-26 22:11:56','2021-04-26 22:11:56','5f104866-a316-4270-8b59-8197ea0ad446'),(202,'plugin:seomatic','m180502_202319_remove_field_metabundles','2021-04-26 22:11:56','2021-04-26 22:11:56','2021-04-26 22:11:56','4d0801b5-be6f-45a1-a79a-33972a2e7583'),(203,'plugin:seomatic','m180711_024947_commerce_products','2021-04-26 22:11:56','2021-04-26 22:11:56','2021-04-26 22:11:56','e1edffef-dd4e-45fc-82f9-772758689a70'),(204,'plugin:seomatic','m190401_220828_longer_handles','2021-04-26 22:11:56','2021-04-26 22:11:56','2021-04-26 22:11:56','16e74a25-6e9e-4a29-b2ae-2353909246ae'),(205,'plugin:seomatic','m190518_030221_calendar_events','2021-04-26 22:11:56','2021-04-26 22:11:56','2021-04-26 22:11:56','6125a321-95ea-40ff-9962-323f9d24b91b'),(206,'plugin:seomatic','m200419_203444_add_type_id','2021-04-26 22:11:56','2021-04-26 22:11:56','2021-04-26 22:11:56','0cf141a0-a63b-4407-bf6f-d7b88757c520'),(207,'plugin:navigation','Install','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','0cf77d4c-4c45-4551-bbbc-8bae945915df'),(208,'plugin:navigation','m180826_000000_propagate_nav_setting','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','d61571b8-2273-4590-a259-69168fb73f18'),(209,'plugin:navigation','m180827_000000_propagate_nav_setting_additional','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','d99e6cd2-dc03-4155-9120-9eeeae80961c'),(210,'plugin:navigation','m181110_000000_add_elementSiteId','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','f3d31681-f3a7-4bff-ab00-7804be2c0939'),(211,'plugin:navigation','m181123_000000_populate_elementSiteIds','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','97ddd34f-fcc4-402a-89ec-7eea8c162e64'),(212,'plugin:navigation','m190203_000000_add_instructions','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','68a49918-909d-4ea2-91d0-296db6ebe801'),(213,'plugin:navigation','m190209_000000_project_config','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','e9d53a62-4a49-4d93-86bf-d46e49494bcd'),(214,'plugin:navigation','m190223_000000_permissions','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','d2776f88-fe68-4239-8112-3725a1fdc50e'),(215,'plugin:navigation','m190307_000000_update_field_content','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','fe81323a-8788-4f37-bc7c-635b6cf50384'),(216,'plugin:navigation','m190310_000000_migrate_elementSiteId','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','52729aaa-6d09-4099-be51-9030501904a9'),(217,'plugin:navigation','m190314_000000_soft_deletes','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','4cd871d0-35cc-480a-a424-4b356ef34b8b'),(218,'plugin:navigation','m190315_000000_project_config','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','28962ea5-2241-49f4-a6b0-176be5274469'),(219,'plugin:navigation','m191127_000000_fix_nav_handle','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','4169ba06-bead-4a05-87e3-977021873003'),(220,'plugin:navigation','m191230_102505_add_fieldLayoutId','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','d4904604-c239-4f6f-a0f8-0ec90b67e251'),(221,'plugin:navigation','m200108_000000_add_attributes','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','24cca741-110e-43f9-af93-0a2c0e02be23'),(222,'plugin:navigation','m200108_100000_add_url_suffix','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','c34af49a-09f1-44b0-820e-2b6e6e68673c'),(223,'plugin:navigation','m200108_200000_add_max_nodes','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','147bd1cf-8437-4f04-b037-c38f8cff3900'),(224,'plugin:navigation','m200205_000000_add_data','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','39fc6e76-22d4-4caf-950c-4a9940ae0bda'),(225,'plugin:navigation','m200810_000000_fix_elementsiteid','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','bb016ccb-24e4-40cb-8d90-96d06a60bfb8'),(226,'plugin:navigation','m200811_000000_fix_uris','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','509a4ad9-2ea5-460d-a439-f67ed1a086ed'),(227,'plugin:navigation','m201017_000000_add_permissions','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','c2d59f8a-ac83-4c3e-a295-32666f579de9'),(228,'plugin:navigation','m201018_000000_site_settings','2021-04-26 22:13:08','2021-04-26 22:13:08','2021-04-26 22:13:08','4c104acc-beef-4950-aca3-5016b974be86');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `navigation_navs`
--

LOCK TABLES `navigation_navs` WRITE;
/*!40000 ALTER TABLE `navigation_navs` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `navigation_navs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `navigation_nodes`
--

LOCK TABLES `navigation_nodes` WRITE;
/*!40000 ALTER TABLE `navigation_nodes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `navigation_nodes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `neoblocks`
--

LOCK TABLES `neoblocks` WRITE;
/*!40000 ALTER TABLE `neoblocks` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `neoblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `neoblockstructures`
--

LOCK TABLES `neoblockstructures` WRITE;
/*!40000 ALTER TABLE `neoblockstructures` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `neoblockstructures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `neoblocktypegroups`
--

LOCK TABLES `neoblocktypegroups` WRITE;
/*!40000 ALTER TABLE `neoblocktypegroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `neoblocktypegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `neoblocktypes`
--

LOCK TABLES `neoblocktypes` WRITE;
/*!40000 ALTER TABLE `neoblocktypes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `neoblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `plugins` VALUES (1,'linkit','1.1.12.1','1.0.8','trial',NULL,'2021-04-26 21:59:54','2021-04-26 21:59:54','2021-04-26 22:14:38','88183683-9daf-459d-aeda-70b31e7fa5b4'),(2,'redactor','2.8.6','2.3.0','unknown',NULL,'2021-04-26 22:07:08','2021-04-26 22:07:08','2021-04-26 22:14:38','a2d44697-bea1-462b-8efd-7461a8cb62a3'),(3,'field-manager','2.2.2','1.0.0','unknown',NULL,'2021-04-26 22:07:33','2021-04-26 22:07:33','2021-04-26 22:14:38','8ba05010-d396-4613-8754-c338fc40b48f'),(4,'neo','2.9.6','2.8.16','trial',NULL,'2021-04-26 22:08:01','2021-04-26 22:08:01','2021-04-26 22:14:38','149d39fb-bd1e-4c13-a0d7-87705903f916'),(5,'matrixmate','1.2.7','1.0.0','unknown',NULL,'2021-04-26 22:08:56','2021-04-26 22:08:56','2021-04-26 22:14:38','3bb731c5-c996-4242-bb77-61f4a0bfcd9c'),(6,'contact-form','2.2.7','1.0.0','unknown',NULL,'2021-04-26 22:09:30','2021-04-26 22:09:30','2021-04-26 22:14:38','87f8f4a5-609d-4842-b963-6214e42c0162'),(7,'contact-form-extensions','1.2.4','1.0.1','unknown',NULL,'2021-04-26 22:10:28','2021-04-26 22:10:28','2021-04-26 22:14:38','bdb6f1a9-293d-4c32-916a-09e3706dd0e3'),(8,'seomatic','3.3.40','3.0.9','trial',NULL,'2021-04-26 22:11:55','2021-04-26 22:11:55','2021-04-26 22:14:38','55cb8476-8bad-4c6e-9eee-5910046dd432'),(9,'navigation','1.4.15','1.0.21','trial',NULL,'2021-04-26 22:13:07','2021-04-26 22:13:07','2021-04-26 22:14:38','0d019d10-389d-493b-9042-691f8ae8e616');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('dateModified','1619475462'),('email.fromEmail','\"tyler@switch.is\"'),('email.fromName','\"Aethon Energy\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.autocapitalize','true'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.autocomplete','false'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.autocorrect','true'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.class','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.disabled','false'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.id','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.instructions','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.label','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.max','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.min','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.name','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.orientation','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.placeholder','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.readonly','false'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.requirable','false'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.size','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.step','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.tip','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.title','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\EntryTitleField\"'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.warning','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.elements.0.width','100'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.name','\"Content\"'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.fieldLayouts.9880c4fc-b0c5-4117-b40c-01d6a44c89e3.tabs.0.sortOrder','1'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.handle','\"home\"'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.hasTitleField','false'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.name','\"Home\"'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.section','\"d57415e2-2b06-44d7-aeb4-dcd04da96ef9\"'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.sortOrder','1'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.titleFormat','\"{section.name|raw}\"'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.titleTranslationKeyFormat','null'),('entryTypes.0cc347c2-5aaa-4dbf-be01-15ca4e30e362.titleTranslationMethod','\"site\"'),('fieldGroups.c7c37252-7715-4730-af7f-51d0ef0c84a6.name','\"Common\"'),('plugins.contact-form-extensions.edition','\"standard\"'),('plugins.contact-form-extensions.enabled','true'),('plugins.contact-form-extensions.schemaVersion','\"1.0.1\"'),('plugins.contact-form.edition','\"standard\"'),('plugins.contact-form.enabled','true'),('plugins.contact-form.schemaVersion','\"1.0.0\"'),('plugins.field-manager.edition','\"standard\"'),('plugins.field-manager.enabled','true'),('plugins.field-manager.schemaVersion','\"1.0.0\"'),('plugins.linkit.edition','\"standard\"'),('plugins.linkit.enabled','true'),('plugins.linkit.licenseKey','\"MVBE0US86WPNJPIVG4QP6PRM\"'),('plugins.linkit.schemaVersion','\"1.0.8\"'),('plugins.matrixmate.edition','\"standard\"'),('plugins.matrixmate.enabled','true'),('plugins.matrixmate.schemaVersion','\"1.0.0\"'),('plugins.navigation.edition','\"standard\"'),('plugins.navigation.enabled','true'),('plugins.navigation.licenseKey','\"V9ZCRJC0I2985JMNUKI4WNFR\"'),('plugins.navigation.schemaVersion','\"1.0.21\"'),('plugins.neo.edition','\"standard\"'),('plugins.neo.enabled','true'),('plugins.neo.licenseKey','\"OE7ANUFFY93XNLO114H4JJ5M\"'),('plugins.neo.schemaVersion','\"2.8.16\"'),('plugins.redactor.edition','\"standard\"'),('plugins.redactor.enabled','true'),('plugins.redactor.schemaVersion','\"2.3.0\"'),('plugins.seomatic.edition','\"standard\"'),('plugins.seomatic.enabled','true'),('plugins.seomatic.licenseKey','\"4JMZDDFZR9CXQUN1X1PIQ4YB\"'),('plugins.seomatic.schemaVersion','\"3.0.9\"'),('sections.d57415e2-2b06-44d7-aeb4-dcd04da96ef9.enableVersioning','true'),('sections.d57415e2-2b06-44d7-aeb4-dcd04da96ef9.handle','\"home\"'),('sections.d57415e2-2b06-44d7-aeb4-dcd04da96ef9.name','\"Home\"'),('sections.d57415e2-2b06-44d7-aeb4-dcd04da96ef9.propagationMethod','\"all\"'),('sections.d57415e2-2b06-44d7-aeb4-dcd04da96ef9.siteSettings.90e9762b-b063-4ecd-a13d-b89d892e304c.enabledByDefault','true'),('sections.d57415e2-2b06-44d7-aeb4-dcd04da96ef9.siteSettings.90e9762b-b063-4ecd-a13d-b89d892e304c.hasUrls','true'),('sections.d57415e2-2b06-44d7-aeb4-dcd04da96ef9.siteSettings.90e9762b-b063-4ecd-a13d-b89d892e304c.template','\"_layout/content_builder\"'),('sections.d57415e2-2b06-44d7-aeb4-dcd04da96ef9.siteSettings.90e9762b-b063-4ecd-a13d-b89d892e304c.uriFormat','\"__home__\"'),('sections.d57415e2-2b06-44d7-aeb4-dcd04da96ef9.type','\"single\"'),('siteGroups.dbafcf18-f5f1-406f-8471-7d418e776758.name','\"Aethon Energy\"'),('sites.90e9762b-b063-4ecd-a13d-b89d892e304c.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.90e9762b-b063-4ecd-a13d-b89d892e304c.handle','\"default\"'),('sites.90e9762b-b063-4ecd-a13d-b89d892e304c.hasUrls','true'),('sites.90e9762b-b063-4ecd-a13d-b89d892e304c.language','\"en-US\"'),('sites.90e9762b-b063-4ecd-a13d-b89d892e304c.name','\"Aethon Energy\"'),('sites.90e9762b-b063-4ecd-a13d-b89d892e304c.primary','true'),('sites.90e9762b-b063-4ecd-a13d-b89d892e304c.siteGroup','\"dbafcf18-f5f1-406f-8471-7d418e776758\"'),('sites.90e9762b-b063-4ecd-a13d-b89d892e304c.sortOrder','1'),('system.edition','\"pro\"'),('system.live','true'),('system.name','\"Aethon Energy\"'),('system.retryDuration','null'),('system.schemaVersion','\"3.6.8\"'),('system.timeZone','\"America/Chicago\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfignames`
--

LOCK TABLES `projectconfignames` WRITE;
/*!40000 ALTER TABLE `projectconfignames` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfignames` VALUES ('0cc347c2-5aaa-4dbf-be01-15ca4e30e362','Home'),('90e9762b-b063-4ecd-a13d-b89d892e304c','Aethon Energy'),('c7c37252-7715-4730-af7f-51d0ef0c84a6','Common'),('d57415e2-2b06-44d7-aeb4-dcd04da96ef9','Home'),('dbafcf18-f5f1-406f-8471-7d418e776758','Aethon Energy');
/*!40000 ALTER TABLE `projectconfignames` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `resourcepaths` VALUES ('16258024','@craft/web/assets/updateswidget/dist'),('289fc24a','@craft/web/assets/recententries/dist'),('37160b4a','@craft/web/assets/pluginstore/dist'),('3799ba75','@app/web/assets/feed/dist'),('43b707f2','@craft/web/assets/dbbackup/dist'),('4f369db0','@lib/garnishjs'),('4fb2503e','@craft/web/assets/utilities/dist'),('53a7d5f4','@app/web/assets/login/dist'),('5a70498e','@lib/fabric'),('61ea8e20','@lib/axios'),('626ce107','@app/web/assets/installer/dist'),('6590bb77','@lib/d3'),('6665948e','@lib/iframe-resizer'),('66e4059a','@app/web/assets/admintable/dist'),('6ac6ab99','@lib/fileupload'),('71190aa','@lib/xregexp'),('722eaa67','@lib/picturefill'),('736a13a9','@craft/web/assets/cp/dist'),('758a96a5','@lib/jquery-touch-events'),('852bd9a9','@nystudio107/seomatic/assetbundles/seomatic/dist'),('8d8fbf87','@app/web/assets/dashboard/dist'),('95dcc2fb','@app/web/assets/updateswidget/dist'),('a1a2fa38','@lib/jquery-ui'),('ab668095','@app/web/assets/recententries/dist'),('adb34ac7','@lib/vue'),('c426325e','@lib/velocity'),('c57b39ac','@app/web/assets/editsection/dist'),('c80f0c54','@lib/element-resize-detector'),('c91aed04','@app/web/assets/cp/dist'),('ceb83c31','@craft/web/assets/craftsupport/dist'),('d7dd420','@lib/selectize'),('e47f2426','@app/web/assets/craftsupport/dist'),('e7a382ac','@craft/web/assets/generalsettings/dist'),('f32cce75','@lib/jquery.payment'),('f763b71','@craft/web/assets/dashboard/dist'),('fe8496e0','@bower/jquery/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES (1,2,1,1,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' tyler switch is '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' admin '),(2,'slug',0,1,' home '),(2,'title',0,1,' home ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,NULL,'Home','home','single',1,'all',NULL,'2021-04-26 19:10:48','2021-04-26 19:10:48',NULL,'d57415e2-2b06-44d7-aeb4-dcd04da96ef9');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__','_layout/content_builder',1,'2021-04-26 19:10:48','2021-04-26 19:10:48','6b3d55e1-6b7f-4b69-ac95-df058fa109ef');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `seomatic_metabundles`
--

LOCK TABLES `seomatic_metabundles` WRITE;
/*!40000 ALTER TABLE `seomatic_metabundles` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `seomatic_metabundles` VALUES (1,'2021-04-26 22:11:56','2021-04-26 22:11:56','a09ea13a-22fc-4894-a3eb-248e84facd59','1.0.55','__GLOBAL_BUNDLE__',1,'__GLOBAL_BUNDLE__','__GLOBAL_BUNDLE__','__GLOBAL_BUNDLE__',NULL,'',1,'[]','2021-04-26 22:11:55','{\"language\":null,\"mainEntityOfPage\":\"WebSite\",\"seoTitle\":\"\",\"siteNamePosition\":\"before\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{seomatic.helper.safeCanonicalUrl()}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"none\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.meta.seoImage}\",\"ogImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"ogImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"none\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.meta.seoImage}\",\"twitterImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"twitterImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}','{\"siteName\":\"Aethon Energy\",\"identity\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"creator\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"facebookSiteVerification\":\"\",\"sameAsLinks\":{\"twitter\":{\"siteName\":\"Twitter\",\"handle\":\"twitter\",\"url\":\"\"},\"facebook\":{\"siteName\":\"Facebook\",\"handle\":\"facebook\",\"url\":\"\"},\"wikipedia\":{\"siteName\":\"Wikipedia\",\"handle\":\"wikipedia\",\"url\":\"\"},\"linkedin\":{\"siteName\":\"LinkedIn\",\"handle\":\"linkedin\",\"url\":\"\"},\"googleplus\":{\"siteName\":\"Google+\",\"handle\":\"googleplus\",\"url\":\"\"},\"youtube\":{\"siteName\":\"YouTube\",\"handle\":\"youtube\",\"url\":\"\"},\"instagram\":{\"siteName\":\"Instagram\",\"handle\":\"instagram\",\"url\":\"\"},\"pinterest\":{\"siteName\":\"Pinterest\",\"handle\":\"pinterest\",\"url\":\"\"},\"github\":{\"siteName\":\"GitHub\",\"handle\":\"github\",\"url\":\"\"},\"vimeo\":{\"siteName\":\"Vimeo\",\"handle\":\"vimeo\",\"url\":\"\"}},\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}','{\"MetaTagContainergeneral\":{\"data\":{\"generator\":{\"charset\":\"\",\"content\":\"SEOmatic\",\"httpEquiv\":\"\",\"name\":\"generator\",\"property\":null,\"include\":true,\"key\":\"generator\",\"environment\":null,\"dependencies\":{\"config\":[\"generatorEnabled\"]},\"tagAttrs\":[]},\"keywords\":{\"charset\":\"\",\"content\":\"{seomatic.meta.seoKeywords}\",\"httpEquiv\":\"\",\"name\":\"keywords\",\"property\":null,\"include\":true,\"key\":\"keywords\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.seoDescription}\",\"httpEquiv\":\"\",\"name\":\"description\",\"property\":null,\"include\":true,\"key\":\"description\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"referrer\":{\"charset\":\"\",\"content\":\"{seomatic.site.referrer}\",\"httpEquiv\":\"\",\"name\":\"referrer\",\"property\":null,\"include\":true,\"key\":\"referrer\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"robots\":{\"charset\":\"\",\"content\":\"{seomatic.meta.robots}\",\"httpEquiv\":\"\",\"name\":\"robots\",\"property\":null,\"include\":true,\"key\":\"robots\",\"environment\":{\"live\":{\"content\":\"{seomatic.meta.robots}\"},\"staging\":{\"content\":\"none\"},\"local\":{\"content\":\"none\"}},\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":{\"fb:profile_id\":{\"charset\":\"\",\"content\":\"{seomatic.site.facebookProfileId}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:profile_id\",\"include\":true,\"key\":\"fb:profile_id\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"fb:app_id\":{\"charset\":\"\",\"content\":\"{seomatic.site.facebookAppId}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:app_id\",\"include\":true,\"key\":\"fb:app_id\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:locale\":{\"charset\":\"\",\"content\":\"{{ craft.app.language |replace({\\\"-\\\": \\\"_\\\"}) }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale\",\"include\":true,\"key\":\"og:locale\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:locale:alternate\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale:alternate\",\"include\":true,\"key\":\"og:locale:alternate\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:site_name\":{\"charset\":\"\",\"content\":\"{seomatic.site.siteName}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:site_name\",\"include\":true,\"key\":\"og:site_name\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:type\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogType}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:type\",\"include\":true,\"key\":\"og:type\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:url\":{\"charset\":\"\",\"content\":\"{seomatic.meta.canonicalUrl}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:url\",\"include\":true,\"key\":\"og:url\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:title\":{\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.ogSiteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"charset\":\"\",\"content\":\"{seomatic.meta.ogTitle}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:title\",\"include\":true,\"key\":\"og:title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogDescription}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:description\",\"include\":true,\"key\":\"og:description\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:image\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImage}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image\",\"include\":true,\"key\":\"og:image\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:image:width\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageWidth}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:width\",\"include\":true,\"key\":\"og:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]},\"tagAttrs\":[]},\"og:image:height\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageHeight}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:height\",\"include\":true,\"key\":\"og:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]},\"tagAttrs\":[]},\"og:image:alt\":{\"charset\":\"\",\"content\":\"{seomatic.meta.ogImageDescription}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:alt\",\"include\":true,\"key\":\"og:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]},\"tagAttrs\":[]},\"og:see_also\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:see_also\",\"include\":true,\"key\":\"og:see_also\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"facebook-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.facebookSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"facebook-domain-verification\",\"property\":null,\"include\":true,\"key\":\"facebook-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"facebookSiteVerification\"]},\"tagAttrs\":[]}},\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":{\"twitter:card\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterCard}\",\"httpEquiv\":\"\",\"name\":\"twitter:card\",\"property\":null,\"include\":true,\"key\":\"twitter:card\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:site\":{\"charset\":\"\",\"content\":\"@{seomatic.site.twitterHandle}\",\"httpEquiv\":\"\",\"name\":\"twitter:site\",\"property\":null,\"include\":true,\"key\":\"twitter:site\",\"environment\":null,\"dependencies\":{\"site\":[\"twitterHandle\"]},\"tagAttrs\":[]},\"twitter:creator\":{\"charset\":\"\",\"content\":\"@{seomatic.meta.twitterCreator}\",\"httpEquiv\":\"\",\"name\":\"twitter:creator\",\"property\":null,\"include\":true,\"key\":\"twitter:creator\",\"environment\":null,\"dependencies\":{\"meta\":[\"twitterCreator\"]},\"tagAttrs\":[]},\"twitter:title\":{\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.twitterSiteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"charset\":\"\",\"content\":\"{seomatic.meta.twitterTitle}\",\"httpEquiv\":\"\",\"name\":\"twitter:title\",\"property\":null,\"include\":true,\"key\":\"twitter:title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:description\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterDescription}\",\"httpEquiv\":\"\",\"name\":\"twitter:description\",\"property\":null,\"include\":true,\"key\":\"twitter:description\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:image\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImage}\",\"httpEquiv\":\"\",\"name\":\"twitter:image\",\"property\":null,\"include\":true,\"key\":\"twitter:image\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:image:width\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageWidth}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:width\",\"property\":null,\"include\":true,\"key\":\"twitter:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]},\"tagAttrs\":[]},\"twitter:image:height\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageHeight}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:height\",\"property\":null,\"include\":true,\"key\":\"twitter:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]},\"tagAttrs\":[]},\"twitter:image:alt\":{\"charset\":\"\",\"content\":\"{seomatic.meta.twitterImageDescription}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:alt\",\"property\":null,\"include\":true,\"key\":\"twitter:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]},\"tagAttrs\":[]}},\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":{\"site\":[\"twitterHandle\"]},\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":{\"google-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.googleSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"google-site-verification\",\"property\":null,\"include\":true,\"key\":\"google-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"googleSiteVerification\"]},\"tagAttrs\":[]},\"bing-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.bingSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"msvalidate.01\",\"property\":null,\"include\":true,\"key\":\"bing-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"bingSiteVerification\"]},\"tagAttrs\":[]},\"pinterest-site-verification\":{\"charset\":\"\",\"content\":\"{seomatic.site.pinterestSiteVerification}\",\"httpEquiv\":\"\",\"name\":\"p:domain_verify\",\"property\":null,\"include\":true,\"key\":\"pinterest-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"pinterestSiteVerification\"]},\"tagAttrs\":[]}},\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":{\"canonical\":{\"crossorigin\":\"\",\"href\":\"{seomatic.meta.canonicalUrl}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"canonical\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"canonical\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"home\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.helper.siteUrl(\\\"/\\\") }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"home\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"home\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"author\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.helper.siteUrl(\\\"/humans.txt\\\") }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"author\",\"sizes\":\"\",\"type\":\"text/plain\",\"include\":true,\"key\":\"author\",\"environment\":null,\"dependencies\":{\"frontend_template\":[\"humans\"]},\"tagAttrs\":[]},\"publisher\":{\"crossorigin\":\"\",\"href\":\"{seomatic.site.googlePublisherLink}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"publisher\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"publisher\",\"environment\":null,\"dependencies\":{\"site\":[\"googlePublisherLink\"]},\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":{\"gtag\":{\"name\":\"Google gtag.js\",\"description\":\"The global site tag (gtag.js) is a JavaScript tagging framework and API that allows you to send event data to AdWords, DoubleClick, and Google Analytics. Instead of having to manage multiple tags for different products, you can use gtag.js and more easily benefit from the latest tracking features and integrations as they become available. [Learn More](https://developers.google.com/gtagjs/)\",\"templatePath\":\"_frontend/scripts/gtagHead.twig\",\"templateString\":\"{% set gtagProperty = googleAnalyticsId.value ??? googleAdWordsId.value ??? dcFloodlightId.value ??? null %}\\n{% if gtagProperty %}\\nwindow.dataLayer = window.dataLayer || [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\nfunction gtag(){dataLayer.push(arguments)};\\ngtag(\'js\', new Date());\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if googleAnalyticsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'anonymize_ip\': #{ipAnonymization.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'link_attribution\': #{enhancedLinkAttribution.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'allow_display_features\': #{displayFeatures.value ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAnalyticsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if googleAdWordsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAdWordsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if dcFloodlightId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ dcFloodlightId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/gtagBody.twig\",\"bodyTemplateString\":\"{% set gtagProperty = googleAnalyticsId.value ??? googleAdWordsId.value ??? dcFloodlightId.value ??? null %}\\n{% if gtagProperty %}\\n<script async src=\\\"{{ gtagScriptUrl.value }}?id={{ gtagProperty }}\\\"></script>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleAnalyticsId\":{\"title\":\"Google Analytics Measurement/Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `G-XXXXXXXXXX` or `UA-XXXXXX-XX`, not the entire script code. [Learn More](https://support.google.com/analytics/answer/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"googleAdWordsId\":{\"title\":\"AdWords Conversion ID\",\"instructions\":\"Only enter the ID, e.g.: `AW-XXXXXXXX`, not the entire script code. [Learn More](https://developers.google.com/adwords-remarketing-tag/)\",\"type\":\"string\",\"value\":\"\"},\"dcFloodlightId\":{\"title\":\"DoubleClick Floodlight ID\",\"instructions\":\"Only enter the ID, e.g.: `DC-XXXXXXXX`, not the entire script code. [Learn More](https://support.google.com/dcm/partner/answer/7568534)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send PageView\",\"instructions\":\"Controls whether the `gtag.js` script automatically sends a PageView to Google Analytics, AdWords, and DoubleClick Floodlight when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"In some cases, you might need to anonymize the IP addresses of hits sent to Google Analytics. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/ip-anonymization)\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Google Analytics Display Features\",\"instructions\":\"The display features plugin for gtag.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/display-features)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Google Analytics Enhanced Link Attribution\",\"instructions\":\"Enhanced link attribution improves click track reporting by automatically differentiating between multiple link clicks that have the same URL on a given page. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"gtagScriptUrl\":{\"title\":\"Google gtag.js Script URL\",\"instructions\":\"The URL to the Google gtag.js tracking script. Normally this should not be changed, unless you locally cache it. The JavaScript `dataLayer` will automatically be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/gtag/js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"gtag\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"googleTagManager\":{\"name\":\"Google Tag Manager\",\"description\":\"Google Tag Manager is a tag management system that allows you to quickly and easily update tags and code snippets on your website. Once the Tag Manager snippet has been added to your website or mobile app, you can configure tags via a web-based user interface without having to alter and deploy additional code. [Learn More](https://support.google.com/tagmanager/answer/6102821?hl=en)\",\"templatePath\":\"_frontend/scripts/googleTagManagerHead.twig\",\"templateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value and not seomatic.helper.isPreview %}\\n{{ dataLayerVariableName.value }} = [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\n(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({\'gtm.start\':\\nnew Date().getTime(),event:\'gtm.js\'});var f=d.getElementsByTagName(s)[0],\\nj=d.createElement(s),dl=l!=\'dataLayer\'?\'&l=\'+l:\'\';j.async=true;j.src=\\n\'{{ googleTagManagerUrl.value }}?id=\'+i+dl;f.parentNode.insertBefore(j,f);\\n})(window,document,\'script\',\'{{ dataLayerVariableName.value }}\',\'{{ googleTagManagerId.value }}\');\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/googleTagManagerBody.twig\",\"bodyTemplateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value and not seomatic.helper.isPreview %}\\n<noscript><iframe src=\\\"{{ googleTagManagerNoScriptUrl.value }}?id={{ googleTagManagerId.value }}\\\"\\nheight=\\\"0\\\" width=\\\"0\\\" style=\\\"display:none;visibility:hidden\\\"></iframe></noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleTagManagerId\":{\"title\":\"Google Tag Manager ID\",\"instructions\":\"Only enter the ID, e.g.: `GTM-XXXXXX`, not the entire script code. [Learn More](https://developers.google.com/tag-manager/quickstart)\",\"type\":\"string\",\"value\":\"\"},\"dataLayerVariableName\":{\"title\":\"DataLayer Variable Name\",\"instructions\":\"The name to use for the JavaScript DataLayer variable. The value of this variable will be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"dataLayer\"},\"googleTagManagerUrl\":{\"title\":\"Google Tag Manager Script URL\",\"instructions\":\"The URL to the Google Tag Manager script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/gtm.js\"},\"googleTagManagerNoScriptUrl\":{\"title\":\"Google Tag Manager Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Google Tag Manager `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/ns.html\"}},\"dataLayer\":[],\"include\":false,\"key\":\"googleTagManager\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"facebookPixel\":{\"name\":\"Facebook Pixel\",\"description\":\"The Facebook pixel is an analytics tool that helps you measure the effectiveness of your advertising. You can use the Facebook pixel to understand the actions people are taking on your website and reach audiences you care about. [Learn More](https://www.facebook.com/business/help/651294705016616)\",\"templatePath\":\"_frontend/scripts/facebookPixelHead.twig\",\"templateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?\\nn.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;\\nn.push=n;n.loaded=!0;n.version=\'2.0\';n.queue=[];t=b.createElement(e);t.async=!0;\\nt.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,\\ndocument,\'script\',\'{{ facebookPixelUrl.value }}\');\\nfbq(\'init\', \'{{ facebookPixelId.value }}\');\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\nfbq(\'track\', \'PageView\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/facebookPixelBody.twig\",\"bodyTemplateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n<noscript><img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none\\\"\\nsrc=\\\"{{ facebookPixelNoScriptUrl.value }}?id={{ facebookPixelId.value }}&ev=PageView&noscript=1\\\" /></noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"facebookPixelId\":{\"title\":\"Facebook Pixel ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://developers.facebook.com/docs/facebook-pixel/api-reference)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Facebook Pixel PageView\",\"instructions\":\"Controls whether the Facebook Pixel script automatically sends a PageView to Facebook Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"facebookPixelUrl\":{\"title\":\"Facebook Pixel Script URL\",\"instructions\":\"The URL to the Facebook Pixel script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://connect.facebook.net/en_US/fbevents.js\"},\"facebookPixelNoScriptUrl\":{\"title\":\"Facebook Pixel Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Facebook Pixel `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.facebook.com/tr\"}},\"dataLayer\":[],\"include\":false,\"key\":\"facebookPixel\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"linkedInInsight\":{\"name\":\"LinkedIn Insight\",\"description\":\"The LinkedIn Insight Tag is a lightweight JavaScript tag that powers conversion tracking, retargeting, and web analytics for LinkedIn ad campaigns.\",\"templatePath\":\"_frontend/scripts/linkedInInsightHead.twig\",\"templateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n_linkedin_data_partner_id = \\\"{{ dataPartnerId.value }}\\\";\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/linkedInInsightBody.twig\",\"bodyTemplateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n<script type=\\\"text/javascript\\\">\\n(function(){var s = document.getElementsByTagName(\\\"script\\\")[0];\\n    var b = document.createElement(\\\"script\\\");\\n    b.type = \\\"text/javascript\\\";b.async = true;\\n    b.src = \\\"{{ linkedInInsightUrl.value }}\\\";\\n    s.parentNode.insertBefore(b, s);})();\\n</script>\\n<noscript>\\n<img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none;\\\" alt=\\\"\\\" src=\\\"{{ linkedInInsightNoScriptUrl.value }}?pid={{ dataPartnerId.value }}&fmt=gif\\\" />\\n</noscript>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"dataPartnerId\":{\"title\":\"LinkedIn Data Partner ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://www.linkedin.com/help/lms/answer/65513/adding-the-linkedin-insight-tag-to-your-website?lang=en)\",\"type\":\"string\",\"value\":\"\"},\"linkedInInsightUrl\":{\"title\":\"LinkedIn Insight Script URL\",\"instructions\":\"The URL to the LinkedIn Insight script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://snap.licdn.com/li.lms-analytics/insight.min.js\"},\"linkedInInsightNoScriptUrl\":{\"title\":\"LinkedIn Insight &lt;noscript&gt; URL\",\"instructions\":\"The URL to the LinkedIn Insight `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://dc.ads.linkedin.com/collect/\"}},\"dataLayer\":[],\"include\":false,\"key\":\"linkedInInsight\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"hubSpot\":{\"name\":\"HubSpot\",\"description\":\"If you\'re not hosting your entire website on HubSpot, or have pages on your website that are not hosted on HubSpot, you\'ll need to install the HubSpot tracking code on your non-HubSpot pages in order to capture those analytics.\",\"templatePath\":null,\"templateString\":null,\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/hubSpotBody.twig\",\"bodyTemplateString\":\"{% if hubSpotId.value is defined and hubSpotId.value %}\\n<script type=\\\"text/javascript\\\" id=\\\"hs-script-loader\\\" async defer src=\\\"{{ hubSpotUrl.value }}{{ hubSpotId.value }}.js\\\"></script>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"hubSpotId\":{\"title\":\"HubSpot ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://knowledge.hubspot.com/articles/kcs_article/reports/install-the-hubspot-tracking-code)\",\"type\":\"string\",\"value\":\"\"},\"hubSpotUrl\":{\"title\":\"HubSpot Script URL\",\"instructions\":\"The URL to the HubSpot script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"//js.hs-scripts.com/\"}},\"dataLayer\":[],\"include\":false,\"key\":\"hubSpot\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"fathom\":{\"name\":\"Fathom\",\"description\":\"Fathom is a simple, light-weight, privacy-first alternative to Google Analytics. So, stop scrolling through pages of reports and collecting gobs of personal data about your visitors, both of which you probably don’t need. [Learn More](https://usefathom.com/)\",\"templatePath\":\"_frontend/scripts/fathomAnalytics.twig\",\"templateString\":\"{% if siteId.value is defined and siteId.value %}\\n(function() {\\nvar tag = document.createElement(\'script\');\\ntag.src = \\\"{{ scriptUrl.value }}\\\";\\ntag.defer = true;\\ntag.setAttribute(\\\"data-site\\\", \\\"{{ siteId.value | raw }}\\\");\\n{% if honorDnt.value %}\\ntag.setAttribute(\\\"data-honor-dnt\\\", \\\"true\\\");\\n{% endif %}\\n{% if disableAutoTracking.value %}\\ntag.setAttribute(\\\"data-auto\\\", \\\"false\\\");\\n{% endif %}\\n{% if ignoreCanonicals.value %}\\ntag.setAttribute(\\\"data-canonical\\\", \\\"false\\\");\\n{% endif %}\\n{% if excludedDomains.value | length %}\\ntag.setAttribute(\\\"data-excluded-domains\\\", \\\"{{ excludedDomains.value | raw }}\\\");\\n{% endif %}\\n{% if includedDomains.value | length %}\\ntag.setAttribute(\\\"data-included-domains\\\", \\\"{{ includedDomains.value | raw }}\\\");\\n{% endif %}\\nvar firstScriptTag = document.getElementsByTagName(\'script\')[0];\\nfirstScriptTag.parentNode.insertBefore(tag, firstScriptTag);\\n})();\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"siteId\":{\"title\":\"Site ID\",\"instructions\":\"Only enter the Site ID, not the entire script code. [Learn More](https://usefathom.com/support/tracking)\",\"type\":\"string\",\"value\":\"\"},\"honorDnt\":{\"title\":\"Honoring Do Not Track (DNT)\",\"instructions\":\"By default we track every visitor to your website, regardless of them having DNT turned on or not. [Learn More](https://usefathom.com/support/tracking-advanced)\",\"type\":\"bool\",\"value\":false},\"disableAutoTracking\":{\"title\":\"Disable automatic tracking\",\"instructions\":\"By default, we track a page view every time a visitor to your website loads a page with our script on it. [Learn More](https://usefathom.com/support/tracking-advanced)\",\"type\":\"bool\",\"value\":false},\"ignoreCanonicals\":{\"title\":\"Ignore canonicals\",\"instructions\":\"If there’s a canonical URL in place, then by default we use it instead of the current URL. [Learn More](https://usefathom.com/support/tracking-advanced)\",\"type\":\"bool\",\"value\":false},\"excludedDomains\":{\"title\":\"Excluded Domains\",\"instructions\":\"You exclude one or several domains, so our tracker will track things on every domain, except the ones excluded. [Learn More](https://usefathom.com/support/tracking-advanced)\",\"type\":\"string\",\"value\":\"\"},\"includedDomains\":{\"title\":\"Included Domains\",\"instructions\":\"If you want to go in the opposite direction and only track stats on a specific domain. [Learn More](https://usefathom.com/support/tracking-advanced)\",\"type\":\"string\",\"value\":\"\"},\"scriptUrl\":{\"title\":\"Fathom Script URL\",\"instructions\":\"The URL to the Fathom tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://cdn.usefathom.com/script.js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"fathom\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"matomo\":{\"name\":\"Matomo\",\"description\":\"Matomo is a Google Analytics alternative that protects your data and your customers\' privacy [Learn More](https://matomo.org/)\",\"templatePath\":\"_frontend/scripts/matomoAnalytics.twig\",\"templateString\":\"{% if siteId.value is defined and siteId.value and scriptUrl.value is defined and scriptUrl.value | length %}\\nvar _paq = window._paq = window._paq || [];\\n{% if sendPageView.value %}\\n_paq.push([\'trackPageView\']);\\n{% endif %}\\n{% if sendPageView.value %}\\n_paq.push([\'enableLinkTracking\']);\\n{% endif %}\\n(function() {\\nvar u=\\\"//{{ scriptUrl.value }}/\\\";\\n_paq.push([\'setTrackerUrl\', u+\'matomo.php\']);\\n_paq.push([\'setSiteId\', {{ siteId.value }}]);\\nvar d=document, g=d.createElement(\'script\'), s=d.getElementsByTagName(\'script\')[0];\\ng.type=\'text/javascript\'; g.async=true; g.src=u+\'matomo.js\'; s.parentNode.insertBefore(g,s);\\n})();\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"siteId\":{\"title\":\"Site ID\",\"instructions\":\"Only enter the Site ID, not the entire script code. [Learn More](https://developer.matomo.org/guides/tracking-javascript-guide)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Matomo PageView\",\"instructions\":\"Controls whether the Matomo script automatically sends a PageView when your pages are loaded. [Learn More](https://developer.matomo.org/api-reference/tracking-javascript)\",\"type\":\"bool\",\"value\":true},\"enableLinkTracking\":{\"title\":\"Enable Link Tracking\",\"instructions\":\"Install link tracking on all applicable link elements. [Learn More](https://developer.matomo.org/api-reference/tracking-javascript)\",\"type\":\"bool\",\"value\":true},\"scriptUrl\":{\"title\":\"Matomo Script URL\",\"instructions\":\"The URL to the Fathom tracking script. This will vary depending on whether you are using Matomo Cloud or Matomo On-Premise. [Learn More](https://developer.matomo.org/guides/tracking-javascript-guide)\",\"type\":\"string\",\"value\":\"\"}},\"dataLayer\":[],\"include\":false,\"key\":\"matomo\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"plausible\":{\"name\":\"Plausible\",\"description\":\"Plausible is a lightweight and open-source website analytics tool. No cookies and fully compliant with GDPR, CCPA and PECR. [Learn More](https://plausible.io/)\",\"templatePath\":\"_frontend/scripts/plausibleAnalytics.twig\",\"templateString\":\"{% if siteDomain.value is defined and siteDomain.value %}\\n(function() {\\nvar tag = document.createElement(\'script\');\\ntag.src = \\\"{{ scriptUrl.value }}\\\";\\ntag.defer = true;\\ntag.setAttribute(\\\"data-domain\\\", \\\"{{ siteDomain.value | raw }}\\\");\\nvar firstScriptTag = document.getElementsByTagName(\'script\')[0];\\nfirstScriptTag.parentNode.insertBefore(tag, firstScriptTag);\\n})();\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"siteDomain\":{\"title\":\"Site Domain\",\"instructions\":\"Only enter the site domain, not the entire script code. [Learn More](https://plausible.io/docs/plausible-script)\",\"type\":\"string\",\"value\":\"\"},\"scriptUrl\":{\"title\":\"Plausible Script URL\",\"instructions\":\"The URL to the Plausible tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://plausible.io/js/plausible.js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"plausible\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"googleAnalytics\":{\"name\":\"Google Analytics (old)\",\"description\":\"Google Analytics gives you the digital analytics tools you need to analyze data from all touchpoints in one place, for a deeper understanding of the customer experience. You can then share the insights that matter with your whole organization. [Learn More](https://www.google.com/analytics/analytics/)\",\"templatePath\":\"_frontend/scripts/googleAnalytics.twig\",\"templateString\":\"{% if trackingId.value is defined and trackingId.value %}\\n(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){\\n(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\\nm=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\\n})(window,document,\'script\',\'{{ analyticsUrl.value }}\',\'ga\');\\nga(\'create\', \'{{ trackingId.value |raw }}\', \'auto\'{% if linker.value %}, {allowLinker: true}{% endif %});\\n{% if ipAnonymization.value %}\\nga(\'set\', \'anonymizeIp\', true);\\n{% endif %}\\n{% if displayFeatures.value %}\\nga(\'require\', \'displayfeatures\');\\n{% endif %}\\n{% if ecommerce.value %}\\nga(\'require\', \'ecommerce\');\\n{% endif %}\\n{% if enhancedEcommerce.value %}\\nga(\'require\', \'ec\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linkid\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linker\');\\n{% endif %}\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\nga(\'send\', \'pageview\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"trackingId\":{\"title\":\"Google Analytics Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `UA-XXXXXX-XX`, not the entire script code. [Learn More](https://support.google.com/analytics/answer/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Google Analytics PageView\",\"instructions\":\"Controls whether the Google Analytics script automatically sends a PageView to Google Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"When a customer of Analytics requests IP address anonymization, Analytics anonymizes the address as soon as technically feasible at the earliest possible stage of the collection network.\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Display Features\",\"instructions\":\"The display features plugin for analytics.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/display-features)\",\"type\":\"bool\",\"value\":false},\"ecommerce\":{\"title\":\"Ecommerce\",\"instructions\":\"Ecommerce tracking allows you to measure the number of transactions and revenue that your website generates. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedEcommerce\":{\"title\":\"Enhanced Ecommerce\",\"instructions\":\"The enhanced ecommerce plug-in for analytics.js enables the measurement of user interactions with products on ecommerce websites across the user\'s shopping experience, including: product impressions, product clicks, viewing product details, adding a product to a shopping cart, initiating the checkout process, transactions, and refunds. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/enhanced-ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Enhanced Link Attribution\",\"instructions\":\"Enhanced Link Attribution improves the accuracy of your In-Page Analytics report by automatically differentiating between multiple links to the same URL on a single page by using link element IDs. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"linker\":{\"title\":\"Linker\",\"instructions\":\"The linker plugin simplifies the process of implementing cross-domain tracking as described in the Cross-domain Tracking guide for analytics.js. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/linker)\",\"type\":\"bool\",\"value\":false},\"analyticsUrl\":{\"title\":\"Google Analytics Script URL\",\"instructions\":\"The URL to the Google Analytics tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.google-analytics.com/analytics.js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"googleAnalytics\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null}},\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"issn\":null,\"about\":null,\"abstract\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"acquireLicensePage\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{parseEnv(seomatic.site.identity.genericUrl)}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"conditionsOfAccess\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{parseEnv(seomatic.site.identity.genericUrl)}#identity\"},\"copyrightYear\":null,\"correction\":null,\"creativeWorkStatus\":null,\"creator\":{\"id\":\"{parseEnv(seomatic.site.creator.genericUrl)}#creator\"},\"dateCreated\":null,\"dateModified\":null,\"datePublished\":null,\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"encodingFormat\":null,\"exampleOfWork\":null,\"expires\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":null,\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"maintainer\":null,\"material\":null,\"materialExtent\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":null,\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sdDatePublished\":null,\"sdLicense\":null,\"sdPublisher\":null,\"sourceOrganization\":null,\"spatial\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporal\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"usageInfo\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"identity\":{\"actionableFeedbackPolicy\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{seomatic.site.identity.genericStreetAddress}\",\"addressLocality\":\"{seomatic.site.identity.genericAddressLocality}\",\"addressRegion\":\"{seomatic.site.identity.genericAddressRegion}\",\"postalCode\":\"{seomatic.site.identity.genericPostalCode}\",\"addressCountry\":\"{seomatic.site.identity.genericAddressCountry}\"},\"aggregateRating\":null,\"alumni\":null,\"areaServed\":null,\"award\":null,\"brand\":null,\"contactPoint\":null,\"correctionsPolicy\":null,\"department\":null,\"dissolutionDate\":null,\"diversityPolicy\":null,\"diversityStaffingReport\":null,\"duns\":\"{seomatic.site.identity.organizationDuns}\",\"email\":\"{seomatic.site.identity.genericEmail}\",\"employee\":null,\"ethicsPolicy\":null,\"event\":null,\"faxNumber\":null,\"founder\":\"{seomatic.site.identity.organizationFounder}\",\"foundingDate\":\"{seomatic.site.identity.organizationFoundingDate}\",\"foundingLocation\":\"{seomatic.site.identity.organizationFoundingLocation}\",\"funder\":null,\"globalLocationNumber\":null,\"hasCredential\":null,\"hasMerchantReturnPolicy\":null,\"hasOfferCatalog\":null,\"hasPOS\":null,\"interactionStatistic\":null,\"isicV4\":null,\"knowsAbout\":null,\"knowsLanguage\":null,\"legalName\":null,\"leiCode\":null,\"location\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.helper.socialTransform(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\",\"width\":\"{seomatic.helper.socialTransformWidth(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\",\"height\":\"{seomatic.helper.socialTransformHeight(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\")}\"},\"makesOffer\":null,\"member\":null,\"memberOf\":null,\"naics\":null,\"numberOfEmployees\":null,\"ownershipFundingInfo\":null,\"owns\":null,\"parentOrganization\":null,\"publishingPrinciples\":null,\"review\":null,\"seeks\":null,\"slogan\":null,\"sponsor\":null,\"subOrganization\":null,\"taxID\":null,\"telephone\":\"{seomatic.site.identity.genericTelephone}\",\"unnamedSourcesPolicy\":null,\"vatID\":null,\"additionalType\":null,\"alternateName\":\"{seomatic.site.identity.genericAlternateName}\",\"description\":\"{seomatic.site.identity.genericDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.site.identity.genericImage}\",\"width\":\"{seomatic.site.identity.genericImageWidth}\",\"height\":\"{seomatic.site.identity.genericImageHeight}\"},\"mainEntityOfPage\":null,\"name\":\"{seomatic.site.identity.genericName}\",\"potentialAction\":null,\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.site.identity.genericUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.site.identity.computedType}\",\"id\":\"{parseEnv(seomatic.site.identity.genericUrl)}#identity\",\"graph\":null,\"include\":true,\"key\":\"identity\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"creator\":{\"actionableFeedbackPolicy\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{seomatic.site.creator.genericStreetAddress}\",\"addressLocality\":\"{seomatic.site.creator.genericAddressLocality}\",\"addressRegion\":\"{seomatic.site.creator.genericAddressRegion}\",\"postalCode\":\"{seomatic.site.creator.genericPostalCode}\",\"addressCountry\":\"{seomatic.site.creator.genericAddressCountry}\"},\"aggregateRating\":null,\"alumni\":null,\"areaServed\":null,\"award\":null,\"brand\":null,\"contactPoint\":null,\"correctionsPolicy\":null,\"department\":null,\"dissolutionDate\":null,\"diversityPolicy\":null,\"diversityStaffingReport\":null,\"duns\":\"{seomatic.site.creator.organizationDuns}\",\"email\":\"{seomatic.site.creator.genericEmail}\",\"employee\":null,\"ethicsPolicy\":null,\"event\":null,\"faxNumber\":null,\"founder\":\"{seomatic.site.creator.organizationFounder}\",\"foundingDate\":\"{seomatic.site.creator.organizationFoundingDate}\",\"foundingLocation\":\"{seomatic.site.creator.organizationFoundingLocation}\",\"funder\":null,\"globalLocationNumber\":null,\"hasCredential\":null,\"hasMerchantReturnPolicy\":null,\"hasOfferCatalog\":null,\"hasPOS\":null,\"interactionStatistic\":null,\"isicV4\":null,\"knowsAbout\":null,\"knowsLanguage\":null,\"legalName\":null,\"leiCode\":null,\"location\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.helper.socialTransform(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\",\"width\":\"{seomatic.helper.socialTransformWidth(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\",\"height\":\"{seomatic.helper.socialTransformHeight(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\")}\"},\"makesOffer\":null,\"member\":null,\"memberOf\":null,\"naics\":null,\"numberOfEmployees\":null,\"ownershipFundingInfo\":null,\"owns\":null,\"parentOrganization\":null,\"publishingPrinciples\":null,\"review\":null,\"seeks\":null,\"slogan\":null,\"sponsor\":null,\"subOrganization\":null,\"taxID\":null,\"telephone\":\"{seomatic.site.creator.genericTelephone}\",\"unnamedSourcesPolicy\":null,\"vatID\":null,\"additionalType\":null,\"alternateName\":\"{seomatic.site.creator.genericAlternateName}\",\"description\":\"{seomatic.site.creator.genericDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.site.creator.genericImage}\",\"width\":\"{seomatic.site.creator.genericImageWidth}\",\"height\":\"{seomatic.site.creator.genericImageHeight}\"},\"mainEntityOfPage\":null,\"name\":\"{seomatic.site.creator.genericName}\",\"potentialAction\":null,\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.site.creator.genericUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.site.creator.computedType}\",\"id\":\"{parseEnv(seomatic.site.creator.genericUrl)}#creator\",\"graph\":null,\"include\":true,\"key\":\"creator\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":{\"humans\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"/* TEAM */\\n\\nCreator: {{ seomatic.site.creator.genericName ?? \\\"n/a\\\" }}\\nURL: {{ seomatic.site.creator.genericUrl ?? \\\"n/a\\\" }}\\nDescription: {{ seomatic.site.creator.genericDescription ?? \\\"n/a\\\" }}\\n\\n/* THANKS */\\n\\nCraft CMS - https://craftcms.com\\nPixel & Tonic - https://pixelandtonic.com\\n\\n/* SITE */\\n\\nStandards: HTML5, CSS3\\nComponents: Craft CMS 3, Yii2, PHP, JavaScript, SEOmatic\\n\",\"siteId\":null,\"include\":true,\"handle\":\"humans\",\"path\":\"humans.txt\",\"template\":\"_frontend/pages/humans.twig\",\"controller\":\"frontend-template\",\"action\":\"humans\"},\"robots\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# robots.txt for {{ siteUrl }}\\n\\n{{ seomatic.helper.sitemapIndex() }}\\n{% switch seomatic.config.environment %}\\n\\n{% case \\\"live\\\" %}\\n\\n# live - don\'t allow web crawlers to index cpresources/ or vendor/\\n\\nUser-agent: *\\nDisallow: /cpresources/\\nDisallow: /vendor/\\nDisallow: /.env\\nDisallow: /cache/\\n\\n{% case \\\"staging\\\" %}\\n\\n# staging - disallow all\\n\\nUser-agent: *\\nDisallow: /\\n\\n{% case \\\"local\\\" %}\\n\\n# local - disallow all\\n\\nUser-agent: *\\nDisallow: /\\n\\n{% default %}\\n\\n# default - don\'t allow web crawlers to index cpresources/ or vendor/\\n\\nUser-agent: *\\nDisallow: /cpresources/\\nDisallow: /vendor/\\nDisallow: /.env\\nDisallow: /cache/\\n\\n{% endswitch %}\\n\",\"siteId\":null,\"include\":true,\"handle\":\"robots\",\"path\":\"robots.txt\",\"template\":\"_frontend/pages/robots.twig\",\"controller\":\"frontend-template\",\"action\":\"robots\"},\"ads\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# ads.txt file for {{ siteUrl }}\\n# More info: https://support.google.com/admanager/answer/7441288?hl=en\\n{{ siteUrl }},123,DIRECT\\n\",\"siteId\":null,\"include\":true,\"handle\":\"ads\",\"path\":\"ads.txt\",\"template\":\"_frontend/pages/ads.twig\",\"controller\":\"frontend-template\",\"action\":\"ads\"}},\"name\":\"Frontend Templates\",\"description\":\"Templates that are rendered on the frontend\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":\"SeomaticEditableTemplate\",\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromCustom\",\"seoTitleField\":\"\",\"siteNamePositionSource\":\"fromCustom\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":true,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":true,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),(2,'2021-04-26 22:11:56','2021-04-26 22:11:56','ea6ddcad-b642-49fa-8ae1-7e30f151191b','1.0.29','section',1,'Home','home','single',NULL,'_layout/content_builder',1,'{\"1\":{\"id\":1,\"sectionId\":1,\"siteId\":1,\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"__home__\",\"template\":\"_layout/content_builder\",\"language\":\"en-us\"}}','2021-04-26 19:10:49','{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{entry.title}\",\"siteNamePosition\":\"\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{entry.url}\",\"robots\":\"\",\"ogType\":\"website\",\"ogTitle\":\"{seomatic.meta.seoTitle}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{seomatic.meta.seoDescription}\",\"ogImage\":\"{seomatic.meta.seoImage}\",\"ogImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"ogImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"ogImageDescription\":\"{seomatic.meta.seoImageDescription}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{seomatic.site.twitterHandle}\",\"twitterTitle\":\"{seomatic.meta.seoTitle}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{seomatic.meta.seoDescription}\",\"twitterImage\":\"{seomatic.meta.seoImage}\",\"twitterImageWidth\":\"{seomatic.meta.seoImageWidth}\",\"twitterImageHeight\":\"{seomatic.meta.seoImageHeight}\",\"twitterImageDescription\":\"{seomatic.meta.seoImageDescription}\"}','{\"siteName\":\"Aethon Energy\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"facebookSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"breadcrumb\":null,\"lastReviewed\":null,\"mainContentOfPage\":null,\"primaryImageOfPage\":null,\"relatedLink\":null,\"reviewedBy\":null,\"significantLink\":null,\"speakable\":null,\"specialty\":null,\"about\":null,\"abstract\":null,\"accessMode\":null,\"accessModeSufficient\":null,\"accessibilityAPI\":null,\"accessibilityControl\":null,\"accessibilityFeature\":null,\"accessibilityHazard\":null,\"accessibilitySummary\":null,\"accountablePerson\":null,\"acquireLicensePage\":null,\"aggregateRating\":null,\"alternativeHeadline\":null,\"associatedMedia\":null,\"audience\":null,\"audio\":null,\"author\":{\"id\":\"{parseEnv(seomatic.site.identity.genericUrl)}#identity\"},\"award\":null,\"character\":null,\"citation\":null,\"comment\":null,\"commentCount\":null,\"conditionsOfAccess\":null,\"contentLocation\":null,\"contentRating\":null,\"contentReferenceTime\":null,\"contributor\":null,\"copyrightHolder\":{\"id\":\"{parseEnv(seomatic.site.identity.genericUrl)}#identity\"},\"copyrightYear\":\"{entry.postDate | date(\\\"Y\\\")}\",\"correction\":null,\"creativeWorkStatus\":null,\"creator\":{\"id\":\"{parseEnv(seomatic.site.identity.genericUrl)}#creator\"},\"dateCreated\":false,\"dateModified\":\"{entry.dateUpdated |atom}\",\"datePublished\":\"{entry.postDate |atom}\",\"discussionUrl\":null,\"editor\":null,\"educationalAlignment\":null,\"educationalUse\":null,\"encoding\":null,\"encodingFormat\":null,\"exampleOfWork\":null,\"expires\":null,\"funder\":null,\"genre\":null,\"hasPart\":null,\"headline\":\"{seomatic.meta.seoTitle}\",\"inLanguage\":\"{seomatic.meta.language}\",\"interactionStatistic\":null,\"interactivityType\":null,\"isAccessibleForFree\":null,\"isBasedOn\":null,\"isFamilyFriendly\":null,\"isPartOf\":null,\"keywords\":null,\"learningResourceType\":null,\"license\":null,\"locationCreated\":null,\"mainEntity\":null,\"maintainer\":null,\"material\":null,\"materialExtent\":null,\"mentions\":null,\"offers\":null,\"position\":null,\"producer\":null,\"provider\":null,\"publication\":null,\"publisher\":{\"id\":\"{parseEnv(seomatic.site.identity.genericUrl)}#creator\"},\"publisherImprint\":null,\"publishingPrinciples\":null,\"recordedAt\":null,\"releasedEvent\":null,\"review\":null,\"schemaVersion\":null,\"sdDatePublished\":null,\"sdLicense\":null,\"sdPublisher\":null,\"sourceOrganization\":null,\"spatial\":null,\"spatialCoverage\":null,\"sponsor\":null,\"temporal\":null,\"temporalCoverage\":null,\"text\":null,\"thumbnailUrl\":null,\"timeRequired\":null,\"translationOfWork\":null,\"translator\":null,\"typicalAgeRange\":null,\"usageInfo\":null,\"version\":null,\"video\":null,\"workExample\":null,\"workTranslation\":null,\"additionalType\":null,\"alternateName\":null,\"description\":\"{seomatic.meta.seoDescription}\",\"disambiguatingDescription\":null,\"identifier\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{seomatic.meta.seoImage}\"},\"mainEntityOfPage\":\"{seomatic.meta.canonicalUrl}\",\"name\":\"{seomatic.meta.seoTitle}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{seomatic.site.siteLinksSearchTarget}\",\"query-input\":\"{seomatic.helper.siteLinksQueryInput()}\"},\"sameAs\":null,\"subjectOf\":null,\"url\":\"{seomatic.meta.canonicalUrl}\",\"context\":\"http://schema.org\",\"type\":\"{seomatic.meta.mainEntityOfPage}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{seomatic.meta.seoTitle}\",\"siteName\":\"{seomatic.site.siteName}\",\"siteNamePosition\":\"{seomatic.meta.siteNamePosition}\",\"separatorChar\":\"{seomatic.config.separatorChar}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebPage\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":true,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":true,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}');
/*!40000 ALTER TABLE `seomatic_metabundles` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'Aethon Energy','2021-04-26 17:22:34','2021-04-26 17:22:34',NULL,'dbafcf18-f5f1-406f-8471-7d418e776758');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,1,'Aethon Energy','default','en-US',1,'$PRIMARY_SITE_URL',1,'2021-04-26 17:22:34','2021-04-26 17:22:34',NULL,'90e9762b-b063-4ecd-a13d-b89d892e304c');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,'admin',NULL,NULL,NULL,'tyler@switch.is','$2y$13$3j.RQmmeHE5hDJjdxck8TelhRK5vyCj1C5mPt4aMAGhC5aHbiuzzq',1,0,0,0,'2021-04-26 19:10:01',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2021-04-26 17:22:35','2021-04-26 17:22:35','2021-04-26 19:10:04','81168b36-68a1-4eb8-9726-2f1208ffd9b6');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2021-04-26 19:10:04','2021-04-26 19:10:04','14d8dc1e-82ed-449d-8dcc-f9f4e637d132'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2021-04-26 19:10:04','2021-04-26 19:10:04','a5b9d861-716d-4e2e-afa0-968ac17b085f'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2021-04-26 19:10:04','2021-04-26 19:10:04','611843e7-43b7-4098-a218-8a414387f394'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2021-04-26 19:10:04','2021-04-26 19:10:04','36c556aa-131b-4bcc-9ba7-39aafbb86842');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'aethon'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-26 22:18:09
